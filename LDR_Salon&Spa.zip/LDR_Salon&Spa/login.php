<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In</title>
    <link rel="icon" href="Logo/circular-logo.png" type="image/png">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/jquery-4.0.0.min.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap">
    
    <style>
    .body {
            font-family: 'Inter', system-ui, -apple-system, 'Segoe UI', sans-serif;
    }
        
    .login-bg{
        background: #f8f9fa;
    }
       
    .auth-card {
        width: 100%;
        max-width: 480px;
        padding: 2rem;
        border-radius: 0.75rem;                                  
        background: #ffffff; 
        border: 1px solid rgba(255, 255, 255, .8);
        box-shadow:
            0 20px 50px rgba(80, 120, 170, .20);
    }

    .icon-tile {
        width: 80px;
        height: 80px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 1.4rem;
       
        box-shadow: 0 8px 20px rgba(0, 0, 0, .10), inset 0 1px 0 #fff;
    }
        
    .icon-tile img {
        width: 100%;
        height: 100%;
        object-fit: contain;
        padding: 5px;
    }

    .btnLogin {
        background: #3d2f22;
        color: #ffffff;
        border: 1px solid #3d2f22;
        transition: all 0.2s ease-in-out;
    }

    .btnLogin:hover,
    .btnLogin:focus,
    .btnLogin:active {
        background: #ffffff;
        border-color: #ffffff;
        color: #3d2f22;
        box-shadow: 0 8px 18px rgba(61, 47, 34, 0.25);
    }
    </style>

</head>

<body class="login-bg d-flex align-items-center justify-content-center min-vh-100 p-4">

    <div class="auth-card text-center">
        <div class="icon-tile mx-auto mb-3 mb-sm-4"><img src="Logo/circular-logo.png" alt="Liny Delos Reyes Logo" ></div>
        <h3 class="fw-semibold mb-sm-3">Welcome Back</h3>
        <p class="text-body-secondary mb-4 mb-sm-5">Enter your credentials to access your account.</p>
        
        <form id="loginForm" class="text-start" novalidate>

            <div class="mb-3 mb-sm-4">
                <label for="txtEmail" class="form-label"><small>Email</small></label>
                <input type="email" class="form-control" id="txtEmail" placeholder="Enter your Email" required>
                <div class="invalid-feedback">Please enter your email.</div>
            </div>

            <div class="mb-3 mb-sm-4">
                <label for="txtPass" class="form-label"><small>Password</small></label>
                <input type="password" class="form-control" id="txtPass" placeholder="Enter your Password" required>
                
                <div class="invalid-feedback">Please enter your password.</div>
            </div>

            <button type="button" id="btnLogin" class="btn btnLogin w-100 py-2 mt-2" onclick="window.location.href='dashboard.php';">Login

            </button>

        </form>
    </div>
    

</body>

</html>