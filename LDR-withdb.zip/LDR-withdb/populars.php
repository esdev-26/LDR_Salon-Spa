<?php
include('connect.php');

if ($error) {
    http_response_code(500);
    echo $error;
    exit;
}

$sql = "
    SELECT
        service,
        COUNT(*) AS total_bookings
    FROM sales
    WHERE sale_date >= DATE_FORMAT(CURDATE(), '%Y-%m-01')
      AND sale_date < DATE_ADD(DATE_FORMAT(CURDATE(), '%Y-%m-01'), INTERVAL 1 MONTH)
      AND status = 'completed'
    GROUP BY service
    ORDER BY total_bookings DESC, service ASC
";

$result = $conn->query($sql);
$services = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];

$maxBookings = 0;
foreach ($services as $service) {
    $count = (int)($service['total_bookings'] ?? 0);
    if ($count > $maxBookings) {
        $maxBookings = $count;
    }
}
?>