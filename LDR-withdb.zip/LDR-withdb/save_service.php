<?php
session_start();

if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'] ?? '', ['admin', 'owner', 'staff'], true)) {
    http_response_code(403);
    echo 'You are not allowed to manage services.';
    exit;
}

include('connect.php');

if ($error) { http_response_code(500); echo $error; exit; }

$id          = (int)($_POST['id'] ?? 0);
$name        = trim($_POST['name'] ?? '');
$category    = $_POST['category'] ?? '';
$price       = (float)($_POST['price'] ?? 0);
$duration    = (int)($_POST['duration'] ?? 0);
$status      = $_POST['status'] ?? 'Active';
$description = trim($_POST['description'] ?? '');
$validCategories = ['Haircut and Styling', 'Massage', 'Hair Color', 'Manicure and Pedicure'];

if ($name === '' || !in_array($category, $validCategories, true) || $price < 0 || $duration < 5) {
    http_response_code(400);
    echo 'Please fill in the form correctly.';
    exit;
}

if ($id === 0) {
    $stmt = $conn->prepare(
        "INSERT INTO services (name, category, price, duration, status, description)
         VALUES (?, ?, ?, ?, ?, ?)"
    );
    $stmt->bind_param("ssdiss", $name, $category, $price, $duration, $status, $description);
    $stmt->execute();
    echo $conn->insert_id;
} else {
    $stmt = $conn->prepare(
        "UPDATE services SET name=?, category=?, price=?, duration=?, status=?, description=?
         WHERE id=?"
    );
    $stmt->bind_param("ssdissi", $name, $category, $price, $duration, $status, $description, $id);
    $stmt->execute();
    echo $id;
}