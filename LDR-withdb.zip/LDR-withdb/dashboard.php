<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: home.php');
    exit;
}

$canManageServices = in_array($_SESSION['role'] ?? '', ['admin', 'owner'], true);
$canManageReports = $canManageServices;

?>
<?php
    include('connect.php');
    if ($error) { die($error); }

    try {
        $conn->begin_transaction();
        $conn->query(
            "UPDATE appointments
             SET status = 'cancelled'
             WHERE status IN ('pending', 'confirmed')
               AND TIMESTAMP(appt_date, appt_time) < CURRENT_TIMESTAMP"
        );
        $completedAppts = $conn->query(
            "SELECT id, client, phone, service, stylist, appt_date, appt_time, price, notes
             FROM appointments WHERE status = 'completed' FOR UPDATE"
        );
        $archiveSale = $conn->prepare(
            "INSERT INTO sales (client, phone, service, service_category, stylist, sale_date, sale_time, status, price, notes)
             VALUES (?, ?, ?, ?, ?, ?, ?, 'completed', ?, ?)"
        );
        $removeAppt = $conn->prepare("DELETE FROM appointments WHERE id = ?");
        while ($completed = $completedAppts->fetch_assoc()) {
            $client = $completed['client'];
            $phone = $completed['phone'];
            $service = $completed['service'];
            $styledServiceCategoryStmt = $conn->prepare("SELECT category FROM services WHERE name = ? LIMIT 1");
            $styledServiceCategoryStmt->bind_param("s", $service);
            $styledServiceCategoryStmt->execute();
            $serviceCategory = (string)($styledServiceCategoryStmt->get_result()->fetch_assoc()['category'] ?? 'Haircut and Styling');
            $stylist = $completed['stylist'];
            $date = $completed['appt_date'];
            $time = $completed['appt_time'];
            $price = (float)$completed['price'];
            $notes = $completed['notes'];
            $archiveSale->bind_param(
                "sssssssds",
                $client,
                $phone,
                $service,
                $serviceCategory,
                $stylist,
                $date,
                $time,
                $price,
                $notes
            );
            $archiveSale->execute();
            $completedId = (int)$completed['id'];
            $removeAppt->bind_param("i", $completedId);
            $removeAppt->execute();
        }
        $conn->commit();
    } catch (mysqli_sql_exception $e) {
        $conn->rollback();
        http_response_code(500);
        die('Could not process appointments.');
    }

    $appts    = $conn->query(
        "SELECT id, client, phone, service, stylist, appt_date,
                TIME_FORMAT(appt_time, '%H:%i') AS appt_time,
                status, price, notes
        FROM appointments"
    );
    $sales    = $conn->query(
        "SELECT id, client, phone, service, service_category, stylist, sale_date,
                TIME_FORMAT(sale_time, '%H:%i') AS sale_time,
                status, price, notes
        FROM sales"
    );
    $clients  = $conn->query(
        "SELECT id, name, phone, email, notes, created_at 
        FROM clients"
        );
    $clientRows = $clients->fetch_all(MYSQLI_ASSOC);
    $clientData = array_map(function ($client) {
        return [
            'id' => (int)$client['id'],
            'name' => $client['name'],
            'phone' => $client['phone'],
            'email' => $client['email'],
            'notes' => $client['notes'],
            'createdAt' => substr((string)$client['created_at'], 0, 10)
        ];
    }, $clientRows);
    $services = $conn->query(
        "SELECT id, name, category, price, duration, status, description 
        FROM services"
        );
    $serviceRows = $services->fetch_all(MYSQLI_ASSOC);
    $staff    = $conn->query(
        "SELECT id, name, status, date_employed, notes 
        FROM staff"
    );

    // makes a PHP value safe to print inside a JS string
    function js($s) {
        return "'" . str_replace(["\\", "'", "\r", "\n", "</"], ["\\\\", "\\'", "", "\\n", "<\\/"], (string)$s) . "'";
    }

    $today      = date('Y-m-d');
    $monthStart = date('Y-m-01');

    $todayAppts   = $conn->query("SELECT COUNT(*) c FROM appointments WHERE appt_date = '$today' AND status != 'cancelled'")->fetch_assoc()['c'];
    $pendingCount = $conn->query("SELECT COUNT(*) c FROM appointments WHERE status = 'pending'")->fetch_assoc()['c'];
    $clientTotal  = $conn->query("SELECT COUNT(*) c FROM clients")->fetch_assoc()['c'];
    $nextMonthStart = date('Y-m-01', strtotime('+1 month', strtotime($monthStart)));
    $clientsNew   = $conn->query("SELECT COUNT(*) c FROM clients WHERE created_at >= '$monthStart' AND created_at < '$nextMonthStart'")->fetch_assoc()['c'];
    $salesRow     = $conn->query("SELECT COALESCE(SUM(price),0) total, COUNT(*) n FROM sales WHERE sale_date = '$today' AND status = 'completed'")->fetch_assoc();

    $upcoming = $conn->query(
        "SELECT client, service, status, TIME_FORMAT(appt_time, '%l:%i %p') AS t
        FROM appointments
        WHERE appt_date = '$today' AND status IN ('pending','confirmed')
        ORDER BY appt_time LIMIT 4"
    );
    $popular = $conn->query(
        "SELECT service, COUNT(*) n FROM sales
        WHERE sale_date >= '$monthStart' AND status = 'completed'
        GROUP BY service ORDER BY n DESC, service ASC LIMIT 4"
    );

    $popularServices = [];
    if ($popular instanceof mysqli_result) {
        while ($row = $popular->fetch_assoc()) {
            $popularServices[] = $row;
        }
    }

    $popularMax = 0;
    foreach ($popularServices as $service) {
        $popularMax = max($popularMax, (int)$service['n']);
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liny Delos Reyes Salon & Spa</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="bootstrap-icons-1.13.1/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/dashboard.css">
    <link rel="icon" href="Logo/circular-logo.png" type="image/png">
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/jquery-4.0.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body class="d-flex flex-column min-vh-100">
    <nav class="navbar fixed-top bg-body-tertiary border-bottom py-0">
        <div class="container-fluid px-3">
            <div class="d-flex align-items-center gap-3 me-auto">
                <button class="navbar-toggler menu-btn px-2 d-lg-none" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="brand-block d-lg-block">
                    <div class="date-label" id="dateLabel"></div>
                    <a class="navbar-brand mb-0" href="#">Home</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="offcanvas-lg offcanvas-start text-white" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
        <div class="offcanvas-header">
            <div class="col d-flex align-items-center gap-3">
                <img src="Logo/circular-logo.png" alt="Liny Delos Reyes Logo" class="img-fluid" style="max-height: 52px;">
                <div class="col">
                    <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Liny Delos Reyes</h5>
                    <h6 class="offcanvas-title">Salon & Spa</h6>
                </div>
            </div>
            <div class="col-auto d-flex flex-column align-items-end">
                <button type="button" class="btn-close btn-close-white d-lg-none" data-bs-dismiss="offcanvas" data-bs-target="#offcanvasNavbar" aria-label="Close"></button>
            </div>
        </div>
        <div class="offcanvas-body d-flex flex-column">
            <div class="container flex-grow-1">
                <div class="d-flex flex-column flex-shrink-0 p-3 text-white" >
                    <span class="fs-6 text-uppercase text-white mb-2">Workspace</span>
                    <ul class="nav nav-pills flex-column mb-auto">
                        <li class="nav-item mb-1">
                            <a href="#overview" class="nav-link text-white" id="link-overview">
                                <i class="bi bi-grid me-2"></i> Overview
                            </a>
                        </li>
                        <li class="nav-item mb-1">
                            <a href="#appointments" class="nav-link text-white" id="link-appointments">
                                <i class="bi bi-calendar-event me-2"></i> Appointments
                            </a>
                        </li>
                        <li class="nav-item mb-1">
                            <a href="#clients" class="nav-link text-white" id="link-clients">
                                <i class="bi bi-people me-2"></i> Clients
                            </a>
                        </li>
                        <li class="nav-item mb-1">
                            <a href="#services" class="nav-link text-white" id="link-services">
                                <i class="bi bi-scissors me-2"></i> Services
                            </a>
                        </li>
                        <?php if(isset($_SESSION['role']) && in_array($_SESSION['role'], ['admin', 'owner'], true)):  
                        ?>
                        <li class="nav-item mb-1">
                            <a href="#team" class="nav-link text-white" id="link-team">
                                <i class="bi bi-person me-2"></i> Team
                            </a>
                        </li>
                        <?php  endif; ?>
                        <li class="nav-item mb-1">
                            <a href="#reports" class="nav-link text-white" id="link-reports">
                                <i class="bi bi-activity me-2"></i> Reports
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
             <div class="px-3 pt-3 pb-3 border-top mt-auto">
                <a href="logout.php" class="btn border btn-lg w-100 rounded-pill shadow-sm d-inline-flex align-items-center justify-content-center gap-2 fw-semibold text-uppercase fs-6 text-white">
                    <i class="bi bi-box-arrow-right"></i>
                    Sign Out
                </a>
            </div>
        </div>
    </div>

    <main class="app-main flex-grow-1 p-4 bg-body-secondary">
        <section class="view" id="view-overview">
            <div class="mb-4">
                <h1 class="h3 mb-1">Overview</h1>
                <p class="text-body-secondary mb-0">Here's how the salon is doing today.</p>
            </div>
            <div class="row row-cols-1 row-cols-sm-2 row-cols-xl-4 g-4 mb-4">
                <div class="col">
                    <div class="card stat-card stat-card-featured border-0 shadow-sm rounded-4 h-100">
                        <div class="card-body p-4">
                            <div class="d-flex justify-content-between align-items-start mb-4">
                                <span class="stat-label">Today's appointments</span>
                                <span class="stat-icon d-inline-flex align-items-center justify-content-center"><i class="bi bi-calendar-check"></i></span>
                            </div>
                            <div class="stat-value mb-2"><?= (int)$todayAppts ?></div> <!--j inupdate koto sa overview -->
                            <small class="stat-label">Scheduled for today</small>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card stat-card border-0 shadow-sm rounded-4 h-100">
                        <div class="card-body p-4">
                            <div class="d-flex justify-content-between align-items-start mb-4">
                                <span class="stat-label">Total clients</span>
                                <span class="stat-icon d-inline-flex align-items-center justify-content-center"><i class="bi bi-people"></i></span>
                            </div>
                            <div class="stat-value mb-2"><?= (int)$clientTotal ?></div> <!--j inupdate koto sa overview -->
                            <small class="text-success fw-semibold"><i class="bi bi-arrow-up-short"></i><span id="overviewClientsNew"><?= (int)$clientsNew ?></span> new this month</small>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card stat-card border-0 shadow-sm rounded-4 h-100">
                        <div class="card-body p-4">
                            <div class="d-flex justify-content-between align-items-start mb-4">
                                <span class="stat-label">Sales today</span>
                                <span class="stat-icon d-inline-flex align-items-center justify-content-center"><i class="bi bi-wallet2"></i></span>
                            </div>
                            <div class="stat-value mb-2">&#8369;<?= number_format($salesRow['total']) ?></div> <!--j inupdate koto sa overview -->
                            <small class="stat-label"><?= (int)$salesRow['n'] ?> services completed</small>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card stat-card border-0 shadow-sm rounded-4 h-100">
                        <div class="card-body p-4">
                            <div class="d-flex justify-content-between align-items-start mb-4">
                                <span class="stat-label">Pending requests</span>
                                <span class="stat-icon d-inline-flex align-items-center justify-content-center"><i class="bi bi-hourglass-split"></i></span>
                            </div>
                            <div class="stat-value mb-2"><?= (int)$pendingCount ?></div>
                            <small class="stat-label">Waiting for confirmation</small>
                        </div>
                    </div>
                </div>
            </div>
            
            
            <div class="row g-4">
                <div class="col-12 col-lg-7">
                    <div class="card border-0 shadow-sm rounded-4 h-100">
                        <div class="card-body p-4">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h2 class="h5 mb-0">Upcoming appointments</h2>
                                <a href="#" id="view-all" class="small link-dark fw-semibold">View all</a>
                            </div>
                            <?php while ($u = $upcoming->fetch_assoc()): ?>
                                <div class="appt-row d-flex align-items-center gap-3 py-3">
                                    <span class="time-pill"><?= htmlspecialchars($u['t']) ?></span>
                                    <div class="flex-grow-1">
                                        <div class="fw-semibold"><?= htmlspecialchars($u['client']) ?></div>
                                        <small class="text-body-secondary"><?= htmlspecialchars($u['service']) ?></small>
                                    </div>
                                    <?php if ($u['status'] === 'confirmed'): ?>
                                        <span class="badge rounded-pill bg-success-subtle text-success-emphasis">Confirmed</span>
                                    <?php else: ?>
                                        <span class="badge rounded-pill bg-warning-subtle text-warning-emphasis">Pending</span>
                                    <?php endif; ?>
                                </div>
                            <?php endwhile; ?>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-lg-5">
                    <div class="card border-0 shadow-sm rounded-4 h-100">
                        <div class="card-body p-4">
                            <h2 class="h5 mb-4">Popular services this month</h2>

                            <?php if ($popularServices): ?>
                                <?php foreach ($popularServices as $service): ?>
                                    <?php
                                        $count = (int)$service['n'];
                                        $percentage = $popularMax > 0 ? ($count / $popularMax) * 100 : 0;
                                    ?>
                                    <div class="mb-4">
                                        <div class="d-flex justify-content-between small mb-2">
                                            <span class="fw-semibold"><?= htmlspecialchars($service['service']) ?></span>
                                            <span class="text-body-secondary"><?= $count ?></span>
                                        </div>
                                        <div class="progress"><div class="progress-bar bg-brown" style="width: <?= $percentage ?>%;"></div></div>
                                    </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <p class="text-body-secondary mb-0">No completed sales this month yet.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
           
        </section>
        <section class="view d-none" id="view-appointments">
            <div class="d-flex flex-wrap justify-content-between align-items-start gap-3 mb-4">
                <div>
                    <h1 class="h3 mb-1">Appointments</h1>
                    <p class="text-body-secondary mb-0">Click an appointment to view its details. Use Edit or Delete to manage it.</p>
                </div>
                <button type="button" id="btnNewAppt" class="btn btn-primary rounded-pill px-4">
                    <i class="bi bi-plus-lg me-2"></i>Create Appointment
                </button>
            </div>

            <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
                <div class="card-body p-4 pb-3">
                    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-3">
                        <h2 class="h5 mb-0">All Appointments</h2>
                        <div class="d-flex flex-wrap gap-2">
                            <div class="input-group" style="max-width: 290px; min-width: 210px;">
                                <span class="input-group-text bg-body"><i class="bi bi-search"></i></span>
                                <input type="search" class="form-control" id="apptSearch" placeholder="Search appointments..." aria-label="Search appointments">
                            </div>
                            <select class="form-select" id="apptStatusFilter" aria-label="Filter appointments by status" style="max-width: 180px;">
                                <option value="all">All statuses</option>
                                <option value="pending">Pending</option>
                                <option value="confirmed">Confirmed</option>
                                <option value="cancelled">Cancelled</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="list-group list-group-flush border-top" id="apptList"></div>
                <div id="apptEmpty" class="text-center text-body-secondary py-5 d-none">No appointments found. Try another search or status.</div>
            </div>
        </section>

        <div class="modal fade" id="apptModal" tabindex="-1" aria-labelledby="apptModalTitle" aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
                <div class="modal-content border-0 rounded-4">
                    <div class="modal-header border-0 px-4 pt-4 pb-0">
                        <h2 class="modal-title h5" id="apptModalTitle">Create appointment</h2>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form id="apptForm">
                        <div class="modal-body px-4 py-3">
                            <input type="hidden" id="f-id">
                            <div class="row g-3">
                                <div class="col-12 col-md-6">
                                    <label class="form-label small fw-semibold" for="f-client">Client name</label>
                                    <select class="form-select" id="f-client" required>
                                        <option value="">Select a client</option>
                                    </select>
                                    <div class="form-text" id="f-client-help">Add a client before creating an appointment.</div>
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="form-label small fw-semibold" for="f-phone">Phone</label>
                                    <input type="tel" class="form-control" id="f-phone" readonly>
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="form-label small fw-semibold" for="f-service">Service</label>
                                    <select class="form-select" id="f-service" required>
                                        <option value="">Select a service</option>
                                    </select>
                                    <div class="form-text" id="f-service-help">Add a service in Services before creating an appointment.</div>
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="form-label small fw-semibold" for="f-stylist">Stylist / therapist</label>
                                    <input type="text" class="form-control" id="f-stylist">
                                </div>
                                <div class="col-6 col-md-3">
                                    <label class="form-label small fw-semibold" for="f-date">Date</label>
                                    <input type="date" class="form-control" id="f-date" required>
                                </div>
                                <div class="col-6 col-md-3">
                                    <label class="form-label small fw-semibold" for="f-time">Time</label>
                                    <input type="time" class="form-control" id="f-time" required>
                                </div>
                                <div class="col-6 col-md-3">
                                    <label class="form-label small fw-semibold" for="f-status">Status</label>
                                    <select class="form-select" id="f-status">
                                        <option value="pending">Pending</option>
                                        <option value="confirmed">Confirmed</option>
                                        <option value="completed">Completed</option>
                                        <option value="cancelled">Cancelled</option>
                                    </select>
                                </div>
                                <div class="col-6 col-md-3">
                                    <label class="form-label small fw-semibold" for="f-price">Price (&#8369;)</label>
                                    <input type="number" class="form-control" id="f-price" min="0" step="1">
                                </div>
                                <div class="col-12">
                                    <label class="form-label small fw-semibold" for="f-notes">Notes</label>
                                    <textarea class="form-control" id="f-notes" rows="3" placeholder="Allergies, preferences, requests..."></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer border-0 justify-content-between px-4 pb-4">
                            <button type="button" id="btnDeleteAppt" class="btn btn-link link-danger text-decoration-none px-0 d-none">
                                <i class="bi bi-trash me-1"></i>Delete
                            </button>
                            <div class="ms-auto d-flex gap-2">
                                <button type="button" class="btn btn-light rounded-pill px-4" data-bs-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary rounded-pill px-4" id="apptSubmitBtn">Save</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-sm">
                <div class="modal-content border-0 rounded-4 text-center">
                    <div class="modal-body p-4">
                        <div class="d-inline-flex rounded-circle bg-danger-subtle text-danger p-3 mb-3">
                            <i class="bi bi-trash fs-3"></i>
                        </div>
                        <h2 class="h5" id="deleteModalTitle">Delete appointment?</h2>
                        <p class="text-body-secondary mb-4">
                            This will permanently remove <strong id="deleteTarget"></strong>. This can't be undone.
                        </p>
                        <div class="d-flex gap-2 justify-content-center">
                            <button type="button" class="btn btn-light rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                            <button type="button" id="btnConfirmDelete" class="btn btn-danger rounded-pill px-4">Delete</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <section class="view d-none" id="view-clients">
            <div class="d-flex flex-wrap justify-content-between align-items-start gap-3 mb-4">
                <div>
                    <h1 class="h3 mb-1">Client Management</h1>
                    <p class="text-body-secondary mb-0">Manage your salon's client information.</p>
                </div>
                <button class="btn btn-primary rounded-pill px-4" type="button" id="clientAddBtn">
                    <i class="bi bi-plus-lg me-2"></i>Add Client
                </button>
            </div>

            <div class="row g-3 mb-4">
                <div class="col-12 col-sm-6 col-xl-4">
                    <div class="card border-0 shadow-sm rounded-4 h-100"><div class="card-body p-4 d-flex align-items-center gap-3">
                        <div class="client-stat-icon bg-primary-subtle text-primary"><i class="bi bi-people fs-4"></i></div>
                        <div><div class="text-body-secondary small">Total clients</div><div class="h3 mb-0" id="clientTotal">0</div></div>
                    </div></div>
                </div>
                <div class="col-12 col-sm-6 col-xl-4">
                    <div class="card border-0 shadow-sm rounded-4 h-100"><div class="card-body p-4 d-flex align-items-center gap-3">
                        <div class="client-stat-icon bg-success-subtle text-success"><i class="bi bi-person-check fs-4"></i></div>
                        <div><div class="text-body-secondary small">With contact details</div><div class="h3 mb-0" id="clientContactTotal">0</div></div>
                    </div></div>
                </div>
                <div class="col-12 col-sm-6 col-xl-4">
                    <div class="card border-0 shadow-sm rounded-4 h-100"><div class="card-body p-4 d-flex align-items-center gap-3">
                        <div class="client-stat-icon bg-warning-subtle text-warning-emphasis"><i class="bi bi-person-plus fs-4"></i></div>
                        <div><div class="text-body-secondary small">Added this month</div><div class="h3 mb-0" id="clientMonthTotal">0</div></div>
                    </div></div>
                </div>
            </div>

            <div class="card border-0 shadow-sm rounded-4">
                <div class="card-body p-3 p-md-4">
                    <div class="d-flex flex-column flex-md-row justify-content-between gap-3 mb-3">
                        <div><h2 class="h5 mb-1">Client list</h2><p class="small text-body-secondary mb-0">Click a client to view details, or use the actions to edit or delete.</p></div>
                        <div class="client-search-wrap"><i class="bi bi-search"></i><input type="search" class="form-control" id="clientSearch" placeholder="Search name, phone, or email" aria-label="Search clients"></div>
                    </div>
                    <div class="table-responsive">
                        <table class="table align-middle table-hover mb-0">
                            <thead><tr><th>Client</th><th>Phone</th><th>Email</th><th>Date added</th><th class="text-end">Actions</th></tr></thead>
                            <tbody id="clientTableBody"></tbody>
                        </table>
                    </div>
                    <div class="text-center text-body-secondary py-5 d-none" id="clientEmptyState">
                        <i class="bi bi-person-lines-fill fs-1 d-block mb-2"></i><div class="fw-semibold text-body">No clients found</div><div class="small">Try another search or add a new client.</div>
                    </div>
                    <div class="small text-body-secondary pt-3" id="clientListCount">Showing 0 clients</div>
                </div>
            </div>
        </section>

        <div class="modal fade" id="clientModal" tabindex="-1" aria-labelledby="clientModalTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered"><div class="modal-content border-0 rounded-4 shadow">
                <form id="clientForm">
                    <div class="modal-header border-0 px-4 pt-4"><div><h2 class="modal-title h5" id="clientModalTitle">Add client</h2><p class="small text-body-secondary mb-0">Enter the client's contact information.</p></div><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div>
                    <div class="modal-body px-4">
                        <input type="hidden" id="clientId">
                        <div class="mb-3"><label for="clientName" class="form-label">Full name <span class="text-danger">*</span></label><input class="form-control" id="clientName" maxlength="100" required placeholder="e.g. Maria Santos"></div>
                        <div class="mb-3"><label for="clientPhone" class="form-label">Phone number <span class="text-danger">*</span></label><input class="form-control" id="clientPhone" maxlength="30" required placeholder="e.g. 0917 123 4567"></div>
                        <div class="mb-3"><label for="clientEmail" class="form-label">Email address</label><input type="email" class="form-control" id="clientEmail" maxlength="150" placeholder="name@example.com"></div>
                        <div class="mb-2"><label for="clientNotes" class="form-label">Notes <span class="text-body-secondary fw-normal">(optional)</span></label><textarea class="form-control" id="clientNotes" rows="3" maxlength="500" placeholder="Optional client preferences or notes"></textarea></div>
                    </div>
                    <div class="modal-footer border-0 px-4 pb-4"><button type="button" class="btn btn-light rounded-pill px-4" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-dark rounded-pill px-4"><i class="bi bi-check2 me-1"></i>Save client</button></div>
                </form>
            </div></div>
        </div>
        <div class="modal fade" id="clientDeleteModal" tabindex="-1" aria-labelledby="clientDeleteTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-sm"><div class="modal-content border-0 rounded-4"><div class="modal-body text-center p-4">
            <div class="client-stat-icon bg-danger-subtle text-danger mx-auto mb-3"><i class="bi bi-trash fs-4"></i></div><h2 class="h5" id="clientDeleteTitle">Delete client?</h2><p class="text-body-secondary small">This removes the client from your client list. Existing appointments will remain.</p>
                <div class="d-flex justify-content-center gap-2"><button type="button" class="btn btn-light rounded-pill px-3" data-bs-dismiss="modal">Cancel</button><button type="button" class="btn btn-danger rounded-pill px-3" id="clientConfirmDelete">Delete</button></div>
            </div></div></div>
        </div>

        <section class="view d-none" id="view-services">
            <div class="d-flex flex-wrap justify-content-between align-items-start gap-3 mb-4">
                <div>
                    <h1 class="h3 mb-1">Services Management</h1>
                    <p class="text-body-secondary mb-0">Click a service to view details, or use Edit and Delete to manage it.</p>
                </div>
                <button class="btn btn-primary rounded-pill px-4" type="button" id="serviceAddBtn">
                    <i class="bi bi-plus-lg me-2"></i>Add Service
                </button>
            </div>

            <div class="row g-3 mb-4">
                <div class="col-12 col-sm-6 col-xl-4"><div class="card border-0 shadow-sm rounded-4 h-100"><div class="card-body p-4 d-flex align-items-center gap-3">
                    <div class="client-stat-icon bg-primary-subtle text-primary"><i class="bi bi-scissors fs-4"></i></div>
                    <div><div class="text-body-secondary small">Total services</div><div class="h3 mb-0" id="serviceTotal">0</div></div>
                </div></div></div>
                <div class="col-12 col-sm-6 col-xl-4"><div class="card border-0 shadow-sm rounded-4 h-100"><div class="card-body p-4 d-flex align-items-center gap-3">
                    <div class="client-stat-icon bg-success-subtle text-success"><i class="bi bi-check-circle fs-4"></i></div>
                    <div><div class="text-body-secondary small">Active services</div><div class="h3 mb-0" id="serviceActiveTotal">0</div></div>
                </div></div></div>
                <div class="col-12 col-sm-6 col-xl-4"><div class="card border-0 shadow-sm rounded-4 h-100"><div class="card-body p-4 d-flex align-items-center gap-3">
                    <div class="client-stat-icon bg-warning-subtle text-warning"><i class="bi bi-currency-exchange fs-4"></i></div>
                    <div><div class="text-body-secondary small">Average price</div><div class="h3 mb-0" id="serviceAverage">₱0.00</div></div>
                </div></div></div>
            </div>

            <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
                <div class="card-body p-4">
                    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-3">
                        <h2 class="h5 mb-0">All Services</h2>
                        <div class="d-flex flex-wrap gap-2">
                            <div class="input-group" style="max-width: 290px; min-width: 210px;">
                                <span class="input-group-text bg-body"><i class="bi bi-search"></i></span>
                                <input type="search" class="form-control" id="serviceSearch" placeholder="Search services..." aria-label="Search services">
                            </div>
                            <select class="form-select" id="serviceCategoryFilter" aria-label="Filter by category" style="max-width: 180px;">
                                <option value="All">All categories</option><option value="Haircut and Styling">Haircut and Styling</option><option value="Massage">Massage</option><option value="Hair Color">Hair Color</option><option value="Manicure and Pedicure">Manicure and Pedicure</option>
                            </select>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table class="table align-middle mb-0">
                            <thead><tr><th style="min-width:220px;">Service</th><th>Service ID</th><th>Category</th><th>Price</th><th>Duration</th><th>Status</th><th class="text-end">Actions</th></tr></thead>
                            <tbody id="serviceTableBody"></tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>

        <!-- Add/Edit Service modal -->
        <div class="modal fade" id="serviceModal" tabindex="-1" aria-labelledby="serviceModalTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered"><div class="modal-content border-0 rounded-4 shadow">
                <form id="serviceForm">
                    <div class="modal-header border-0 pb-0"><div><h2 class="modal-title h5" id="serviceModalTitle">Add service</h2><p class="text-body-secondary small mb-0">Enter the service details below.</p></div><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div>
                    <div class="modal-body">
                        <div class="mb-3"><label class="form-label" for="serviceName">Service name <span class="text-danger">*</span></label><input class="form-control" id="serviceName" maxlength="100" required placeholder="e.g. Haircut"></div>
                        <div class="row g-3">
                            <div class="col-sm-6"><label class="form-label" for="serviceCategory">Category <span class="text-danger">*</span></label><select class="form-select" id="serviceCategory" required><option value="Haircut and Styling">Haircut and Styling</option><option value="Massage">Massage</option><option value="Hair Color">Hair Color</option><option value="Manicure and Pedicure">Manicure and Pedicure</option></select></div>
                            <div class="col-sm-6"><label class="form-label" for="servicePrice">Price (₱) <span class="text-danger">*</span></label><input class="form-control" id="servicePrice" type="number" min="0" max="1000000" step="0.01" required placeholder="250.00"></div>
                            <div class="col-sm-6"><label class="form-label" for="serviceDuration">Duration (minutes) <span class="text-danger">*</span></label><input class="form-control" id="serviceDuration" type="number" min="5" max="1440" step="5" required value="30"></div>
                            <div class="col-sm-6"><label class="form-label" for="serviceStatus">Status</label><select class="form-select" id="serviceStatus"><option value="Active">Active</option><option value="Inactive">Inactive</option></select></div>
                        </div>
                        <div class="mt-3"><label class="form-label" for="serviceDescription">Description (optional)</label><textarea class="form-control" id="serviceDescription" rows="2" maxlength="300" placeholder="Short description of the service"></textarea></div>
                    </div>
                    <div class="modal-footer border-0 pt-0"><button type="button" class="btn btn-light rounded-pill px-4" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-dark rounded-pill px-4">Save Service</button></div>
                </form>
            </div></div>
        </div>

        <div class="modal fade" id="serviceDeleteModal" tabindex="-1" aria-labelledby="serviceDeleteTitle" aria-hidden="true"><div class="modal-dialog modal-dialog-centered"><div class="modal-content border-0 rounded-4 shadow">
            <div class="modal-header border-0"><h2 class="modal-title h5" id="serviceDeleteTitle">Delete service?</h2><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div>
            <div class="modal-body">Are you sure you want to delete this service? This action cannot be undone in this browser.</div>
            <div class="modal-footer border-0"><button type="button" class="btn btn-light rounded-pill px-4" data-bs-dismiss="modal">Cancel</button><button type="button" class="btn btn-danger rounded-pill px-4" id="serviceConfirmDelete">Delete</button></div>
        </div></div></div>
        <section class="view d-none" id="view-team">
            <div class="d-flex flex-wrap justify-content-between align-items-start gap-3 mb-4">
                <div>
                    <h1 class="h3 mb-1">Team</h1>
                    <p class="text-body-secondary mb-0">Click a staff member to view details. Use Edit or Delete to manage the record.</p>
                </div>
                <button type="button" id="btnNewEmp" class="btn btn-primary rounded-pill px-4">
                    <i class="bi bi-plus-lg me-2"></i>Add Staff
                </button>
            </div>

            <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
                <div class="card-body p-4 pb-3">
                    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-3">
                        <h2 class="h5 mb-0">All Staff</h2>
                        <div class="d-flex flex-wrap gap-2">
                            <div class="input-group" style="max-width: 290px; min-width: 210px;">
                                <span class="input-group-text bg-body"><i class="bi bi-search"></i></span>
                                <input type="search" class="form-control" id="empSearch" placeholder="Search staff..." aria-label="Search staff">
                            </div>
                            <select class="form-select" id="empStatusFilter" aria-label="Filter by employment status" style="max-width: 190px;">
                                <option value="All">All statuses</option>
                                <option value="Employed">Employed</option>
                                <option value="Resigned">Resigned</option>
                                <option value="Terminated">Terminated</option>
                                <option value="Retired">Retired</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="list-group list-group-flush border-top" id="empList"></div>
                <div id="empEmpty" class="text-center text-body-secondary py-5 d-none">No staff found. Try another search or status.</div>
                <div class="small text-body-secondary px-4 py-3" id="empListCount"></div>
            </div>
        </section>

        <div class="modal fade" id="empModal" tabindex="-1" aria-labelledby="empModalTitle" aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
                <div class="modal-content border-0 rounded-4">
                    <div class="modal-header border-0 px-4 pt-4 pb-0">
                        <h2 class="modal-title h5" id="empModalTitle">Add Staff</h2>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form id="empForm">
                        <div class="modal-body px-4 py-3">
                            <input type="hidden" id="emp-id">
                            <div class="row g-3">
                                <div class="col-12 col-md-6">
                                    <label class="form-label small fw-semibold" for="emp-Employees">Staff name</label>
                                    <input type="text" class="form-control" id="emp-Employees" required>
                                </div>
                                <div class="col-6 col-md-3">
                                    <label class="form-label small fw-semibold" for="emp-date">Date of Employment</label>
                                    <input type="date" class="form-control" id="emp-date" required>
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="form-label small fw-semibold" for="emp-status">Status</label>
                                    <select class="form-select" id="emp-status">
                                        <option value="Employed">Employed</option>
                                        <option value="Resigned">Resigned</option>
                                        <option value="Terminated">Terminated</option>
                                        <option value="Retired">Retired</option>
                                    </select>
                                </div>
                                <div class="col-12">
                                    <label class="form-label small fw-semibold" for="emp-notes">Notes</label>
                                    <textarea class="form-control" id="emp-notes" rows="4"></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer border-0 justify-content-between px-4 pb-4">
                            <button type="button" id="btnDeleteEmp" class="btn btn-link link-danger text-decoration-none px-0 d-none">
                                <i class="bi bi-trash me-1"></i>Delete
                            </button>
                            <div class="ms-auto d-flex gap-2">
                                <button type="button" class="btn btn-light rounded-pill px-4" data-bs-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary rounded-pill px-4">Save</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <section class="view d-none" id="view-reports">
            <div class="d-flex flex-wrap justify-content-between align-items-start gap-3 mb-4">
                <div>
                    <h1 class="h3 mb-1">Reports</h1>
                    <p class="text-body-secondary mb-0">Completed appointments and walk-in sales are recorded here. Click a sale to view details.</p>
                </div>
                <?php if ($canManageReports): ?>
                    <button type="button" class="btn btn-primary rounded-pill px-4" id="addWalkInSale">
                        <i class="bi bi-plus-lg me-2"></i>Add Walk-in
                    </button>
                <?php endif; ?>
            </div>

            <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
                <div class="card-body p-4 pb-3">
                    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-3">
                        <div>
                            <h2 class="h5 mb-0">All The Sales</h2>
                        </div>
                        <div class="d-flex flex-wrap gap-2">
                            <div class="input-group" style="max-width: 290px; min-width: 210px;">
                                <span class="input-group-text bg-body"><i class="bi bi-search"></i></span>
                                <input type="search" class="form-control" id="saleSearch" placeholder="Search sales..." aria-label="Search sales">
                            </div>
                            <select class="form-select" id="saleCategoryFilter" aria-label="Filter by category" style="max-width: 220px;">
                                <option value="ALL">All categories</option>
                                <option value="Haircut and styling">Haircut and Styling</option>
                                <option value="Massage">Massage</option>
                                <option value="Hair color">Hair Color</option>
                                <option value="Manicure and pedicure">Manicure and Pedicure</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="list-group list-group-flush border-top" id="saleList"></div>
                <div id="saleEmpty" class="text-center text-body-secondary py-5 d-none">No Sales here yet.</div>
            </div>
        </section>

        <div class="modal fade" id="saleModal" tabindex="-1" aria-labelledby="saleModalTitle" aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
                <div class="modal-content border-0 rounded-4">
                    <div class="modal-header border-0 px-4 pt-4 pb-0">
                        <div>
                            <h2 class="modal-title h5" id="saleModalTitle">Edit sale</h2>
                            <p class="small text-body-secondary mb-0">Update the completed sale details.</p>
                        </div>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form id="saleForm">
                        <div class="modal-body px-4 py-3">
                            <input type="hidden" id="sale-id">
                            <div class="row g-3">
                                <div class="col-12 col-md-6">
                                    <label class="form-label small fw-semibold" for="sale-client">Client</label>
                                    <input type="text" class="form-control" id="sale-client" maxlength="100" required>
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="form-label small fw-semibold" for="sale-phone">Phone</label>
                                    <input type="text" class="form-control" id="sale-phone" maxlength="30">
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="form-label small fw-semibold" for="sale-service">Service</label>
                                    <input type="text" class="form-control" id="sale-service" maxlength="100" required>
                                    <select class="form-select d-none" id="walkInServiceSelect" required disabled>
                                        <option value="">Select a service</option>
                                    </select>
                                    <input type="hidden" id="sale-service-category">
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="form-label small fw-semibold" for="sale-stylist">Stylist / therapist</label>
                                    <input type="text" class="form-control" id="sale-stylist" maxlength="100">
                                </div>
                                <div class="col-6 col-md-3">
                                    <label class="form-label small fw-semibold" for="sale-date">Date</label>
                                    <input type="date" class="form-control" id="sale-date" required>
                                </div>
                                <div class="col-6 col-md-3">
                                    <label class="form-label small fw-semibold" for="sale-time">Time</label>
                                    <input type="time" class="form-control" id="sale-time">
                                </div>
                                <div class="col-6 col-md-3">
                                    <label class="form-label small fw-semibold" for="sale-status">Status</label>
                                    <select class="form-select" id="sale-status">
                                        <option value="completed">Completed</option>
                                        <option value="cancelled">Cancelled</option>
                                    </select>
                                </div>
                                <div class="col-6 col-md-3">
                                    <label class="form-label small fw-semibold" for="sale-price">Price (₱)</label>
                                    <input type="number" class="form-control" id="sale-price" min="0" step="0.01" required>
                                </div>
                                <div class="col-12">
                                    <label class="form-label small fw-semibold" for="sale-notes">Notes</label>
                                    <textarea class="form-control" id="sale-notes" rows="3"></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer border-0 px-4 pb-4">
                            <button type="button" class="btn btn-light rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary rounded-pill px-4">Save changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </main>

    <script>
        $(function () {
            var days = ['SUNDAY','MONDAY','TUESDAY','WEDNESDAY','THURSDAY','FRIDAY','SATURDAY'];
            var months = ['JANUARY','FEBRUARY','MARCH','APRIL','MAY','JUNE','JULY','AUGUST','SEPTEMBER','OCTOBER','NOVEMBER','DECEMBER'];
            var now = new Date();
            var formatted = days[now.getDay()] + ' · ' + now.getDate() + ' ' + months[now.getMonth()] + ' ' + now.getFullYear();
            $('#dateLabel').text(formatted);
        });

        

        /*j binago ko yung code para dynamic nagbabago yung display nya ng data */
        $(function () {

            // Show the correct section when the page loads
            function showSelectedTab() {
                var tabName = window.location.hash.substring(1) || 'overview';

                var link = document.getElementById('link-' + tabName);
                var section = document.getElementById('view-' + tabName);

                // If the URL hash is invalid, show Overview
                if (!link || !section) {
                    tabName = 'overview';
                    link = document.getElementById('link-overview');
                    section = document.getElementById('view-overview');
                }

                $('#offcanvasNavbar .nav-link').removeClass('active');
                $(link).addClass('active');

                $('.view').addClass('d-none');
                $(section).removeClass('d-none');
            }

            // Reload the page whenever a dashboard tab is clicked
            $('#offcanvasNavbar .nav-link').on('click', function (e) {
                e.preventDefault();

                var tabName = this.id.replace('link-', '');
                var newHash = '#' + tabName;

                // Save the selected tab in the URL
                if (window.location.hash !== newHash) {
                    window.location.hash = newHash;
                }

                // Reload PHP and retrieve the latest database data
                window.location.reload();
            });

            // Restore the selected tab after reloading
            showSelectedTab();

            // Close the mobile navigation menu
            $('#offcanvasNavbar .nav-link').on('click', function () {
                if (window.matchMedia('(max-width: 991.98px)').matches) {
                    bootstrap.Offcanvas
                        .getOrCreateInstance(
                            document.getElementById('offcanvasNavbar')
                        )
                        .hide();
                }
            });

        });

        
        $('#view-all').on('click', function (e) {
            e.preventDefault();
            $('#link-appointments').trigger('click');
        });

        /*-----------Appointments Sample Data---------------*/
        (function () {
            var STATUS = {
                pending:   { label: 'Pending',   bar: 'bg-warning', badge: 'bg-warning-subtle text-warning-emphasis' },
                confirmed: { label: 'Confirmed', bar: 'bg-success', badge: 'bg-success-subtle text-success-emphasis' },
                completed: { label: 'Completed', bar: 'bg-info',    badge: 'bg-info-subtle text-info-emphasis' },
                cancelled: { label: 'Cancelled', bar: 'bg-danger',  badge: 'bg-danger-subtle text-danger-emphasis' }
            };

            function iso(d) {
                return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
            }
            function day(n) { var d = new Date(); d.setDate(d.getDate() + n); return iso(d); }
            function esc(s) {
                return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
                    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
                });
            }
            function fmtTime(t) {
                return new Date('1970-01-01T' + t).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
            }
            function fmtDate(d) {
                return new Date(d + 'T00:00').toLocaleDateString([], { month: 'short', day: 'numeric' });
            }

            /*j retrieving ng appointments data */
            var list = [
            <?php while ($r = $appts->fetch_assoc()): ?>
                {
                    id:      <?= (int)$r['id'] ?>,
                    client:  <?= js($r['client']) ?>,
                    phone:   <?= js($r['phone']) ?>,
                    service: <?= js($r['service']) ?>,
                    stylist: <?= js($r['stylist']) ?>,
                    date:    <?= js($r['appt_date']) ?>,
                    time:    <?= js($r['appt_time']) ?>,
                    status:  <?= js($r['status']) ?>,
                    price:   <?= (float)$r['price'] ?>,
                    notes:   <?= js($r['notes']) ?>
                },
            <?php endwhile; ?>
            ];
            var clients = <?= json_encode($clientData, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT) ?>;
            window.dashboardClients = clients;
            var availableServices = <?= json_encode($serviceRows, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT) ?>;
            window.dashboardServices = availableServices;
            var nextId = 100, newId = null, filter = 'all';

            var listEl = document.getElementById('apptList');
            var emptyEl = document.getElementById('apptEmpty');
            var modalEl = document.getElementById('apptModal');
            var modal = bootstrap.Modal.getOrCreateInstance(modalEl);
            var form = document.getElementById('apptForm');
            var $ = function (id) { return document.getElementById(id); };

            function populateClients(selectedId) {
                var clientSelect = $('f-client');
                clientSelect.innerHTML = '<option value="">Select a client</option>';
                clients.slice().sort(function (a, b) { return a.name.localeCompare(b.name); }).forEach(function (client) {
                    var option = document.createElement('option');
                    option.value = String(client.id);
                    option.textContent = client.name + (client.phone ? ' · ' + client.phone : '');
                    clientSelect.appendChild(option);
                });
                clientSelect.value = selectedId ? String(selectedId) : '';
                clientSelect.disabled = clients.length === 0;
                $('f-client-help').classList.toggle('d-none', clients.length > 0);
                return clientSelect.value;
            }

            function populateServices(selectedName, allowLegacy) {
                var serviceSelect = $('f-service');
                var activeServices = availableServices.filter(function (service) { return service.status === 'Active'; });
                serviceSelect.innerHTML = '<option value="">Select a service</option>';
                activeServices.forEach(function (service) {
                    var option = document.createElement('option');
                    option.value = String(service.id);
                    option.textContent = service.name;
                    option.dataset.price = service.price;
                    serviceSelect.appendChild(option);
                });
                var selected = activeServices.find(function (service) { return service.name === selectedName; });
                if (!selected && allowLegacy && selectedName) {
                    var legacyOption = document.createElement('option');
                    legacyOption.value = 'legacy';
                    legacyOption.textContent = selectedName + ' (inactive or unavailable)';
                    serviceSelect.appendChild(legacyOption);
                    serviceSelect.value = 'legacy';
                } else if (selected) {
                    serviceSelect.value = String(selected.id);
                } else if (activeServices.length) {
                    serviceSelect.value = String(activeServices[0].id);
                }
                serviceSelect.disabled = activeServices.length === 0;
                $('apptSubmitBtn').disabled = activeServices.length === 0;
                $('f-service-help').classList.toggle('d-none', activeServices.length > 0);
                return activeServices;
            }

            window.addEventListener('services-updated', function (event) {
                availableServices = event.detail;
                populateServices();
            });
            window.addEventListener('clients-updated', function (event) {
                clients = event.detail;
                var selectedId = populateClients($('f-client').value);
                var selectedClient = clients.find(function (client) { return String(client.id) === selectedId; });
                $('f-phone').value = selectedClient ? selectedClient.phone : '';
            });
            $('f-client').addEventListener('change', function () {
                var selectedId = this.value;
                var selectedClient = clients.find(function (client) { return String(client.id) === selectedId; });
                $('f-phone').value = selectedClient ? selectedClient.phone : '';
            });
            $('f-service').addEventListener('change', function () {
                var option = this.options[this.selectedIndex];
                if (option && option.dataset.price) $('f-price').value = option.dataset.price;
            });

            /* Add New Appointment*/
            function render() {
                var query = $('apptSearch').value.trim().toLowerCase();
                var shown = list.filter(function (a) {
                    var searchableText = [a.client, a.phone, a.service, a.stylist, a.date, a.time, a.status].join(' ').toLowerCase();
                    return (filter === 'all' || a.status === filter) && searchableText.includes(query);
                })
                    .sort(function (a, b) { return b.id - a.id; });

                listEl.innerHTML = shown.map(function (a) {
                    var s = STATUS[a.status];
                    var off = a.status === 'cancelled';
                    return '<div class="list-group-item d-flex flex-wrap flex-md-nowrap align-items-center gap-3 px-4 py-3">' +
                        '<div class="list-group-item-action d-flex flex-grow-1 align-items-center gap-3" style="min-width:0" data-appt-view="' + a.id + '" role="button" tabindex="0" aria-label="View appointment for ' + esc(a.client) + '">' +
                        '<span class="time-pill' + (off ? ' opacity-50' : '') + '">' + fmtTime(a.time) + '</span>' +
                        '<div class="flex-grow-1"><div class="fw-semibold' + (off ? ' text-decoration-line-through text-body-secondary' : '') + '">' + esc(a.client) +
                        (a.id === newId ? ' <span class="badge text-bg-primary ms-1">New</span>' : '') + '</div>' +
                        '<small class="text-body-secondary">' + esc(a.service) + (a.stylist ? ' &middot; ' + esc(a.stylist) : '') + '</small></div>' +
                        '<div class="text-end"><span class="badge rounded-pill ' + s.badge + '">' + s.label + '</span>' +
                        '<div class="small text-body-secondary mt-1">' + fmtDate(a.date) + '</div></div></div>' +
                        '<div class="d-flex flex-shrink-0 gap-1">' +
                        '<button type="button" class="btn btn-sm btn-outline-secondary rounded-pill" data-appt-edit="' + a.id + '" aria-label="Edit appointment for ' + esc(a.client) + '"><i class="bi bi-pencil me-1"></i>Edit</button>' +
                        '<button type="button" class="btn btn-sm btn-outline-danger rounded-pill" data-appt-delete="' + a.id + '" aria-label="Delete appointment for ' + esc(a.client) + '"><i class="bi bi-trash"></i></button>' +
                        '</div></div>';
                }).join('');

                emptyEl.textContent = list.length
                    ? 'No appointments found. Try another search or status.'
                    : 'No appointments here yet.';
                emptyEl.classList.toggle('d-none', shown.length > 0);
            }

            /* Add or Edit modal if else */
            function openModal(a, readOnly) {
                form.reset();
                Array.prototype.forEach.call(form.querySelectorAll('input:not([type="hidden"]), select, textarea'), function (field) {
                    field.disabled = false;
                });
                $('apptModalTitle').textContent = readOnly ? 'View appointment' : (a ? 'Edit appointment' : 'Create appointment');
                $('btnDeleteAppt').classList.toggle('d-none', !a || readOnly);
                $('apptSubmitBtn').classList.toggle('d-none', !!readOnly);
                $('f-id').value     = a ? a.id : '';
                var selectedClient = a && clients.find(function (client) {
                    return client.name === a.client && (!a.phone || client.phone === a.phone);
                });
                if (!selectedClient && a) {
                    selectedClient = clients.find(function (client) { return client.name === a.client; });
                }
                populateClients(selectedClient ? selectedClient.id : '');
                $('f-phone').value  = a ? a.phone : (selectedClient ? selectedClient.phone : '');
                var activeServices = populateServices(a ? a.service : '', !!a);
                $('f-stylist').value= a ? a.stylist : '';
                $('f-date').value   = a ? a.date : day(0);
                $('f-time').value   = a ? a.time : '';
                $('f-status').value = a ? a.status : 'pending';
                var selectedService = activeServices.find(function (service) { return String(service.id) === $('f-service').value; });
                $('f-price').value  = a ? a.price : (selectedService ? selectedService.price : '');
                $('f-notes').value  = a ? a.notes : '';
                if (readOnly) {
                    Array.prototype.forEach.call(form.querySelectorAll('input:not([type="hidden"]), select, textarea'), function (field) {
                        field.disabled = true;
                    });
                }
                modal.show();
            }

            function findById(id) { return list.filter(function (a) { return String(a.id) === String(id); })[0]; }

            $('btnNewAppt').addEventListener('click', function () {
                if (!clients.length) {
                    Swal.fire({
                        icon: 'info',
                        title: 'Create a client first',
                        text: 'Add a client before creating an appointment.',
                        confirmButtonText: 'Add client',
                        showCancelButton: true,
                        cancelButtonText: 'Cancel'
                    }).then(function (result) {
                        if (result.isConfirmed) bootstrap.Modal.getOrCreateInstance(document.getElementById('clientModal')).show();
                    });
                    return;
                }
                openModal(null, false);
            });

            function openFromCard(e) {
                var editButton = e.target.closest('[data-appt-edit]');
                var deleteButton = e.target.closest('[data-appt-delete]');
                if (editButton) {
                    var editableAppointment = findById(editButton.dataset.apptEdit);
                    if (editableAppointment) openModal(editableAppointment, false);
                    return;
                }
                if (deleteButton) {
                    pendingDeleteId = deleteButton.dataset.apptDelete;
                    returnToAppointmentModal = false;
                    var deleteAppointment = findById(pendingDeleteId);
                    $('deleteTarget').textContent = deleteAppointment
                        ? deleteAppointment.client + ' (' + fmtDate(deleteAppointment.date) + ', ' + fmtTime(deleteAppointment.time) + ')'
                        : 'this appointment';
                    confirmModal.show();
                    return;
                }
                var card = e.target.closest('[data-appt-view]');
                if (card) openModal(findById(card.dataset.apptView), true);
            }
            listEl.addEventListener('click', openFromCard);
            listEl.addEventListener('keydown', function (e) {
                if (e.target.closest('[data-appt-view]') && (e.key === 'Enter' || e.key === ' ')) {
                    if (e.key === ' ') e.preventDefault();
                    openFromCard(e);
                }
            });

            $('apptStatusFilter').addEventListener('change', function () {
                filter = this.value;
                render();
            });
            $('apptSearch').addEventListener('input', render);

            /*j inupdate koto para everytime magsubmit nagsesend ng data sa php*/
            form.addEventListener('submit', function (e) {
                e.preventDefault();
                if ($('apptSubmitBtn').classList.contains('d-none')) return;
                var selectedOption = $('f-service').options[$('f-service').selectedIndex];
                var selectedClient = clients.find(function (client) { return String(client.id) === $('f-client').value; });
                if (!selectedClient || !selectedOption || !selectedOption.value) return;
                var data = {
                    client_id: selectedClient.id, client: selectedClient.name, phone: selectedClient.phone,
                    service_id: $('f-service').value === 'legacy' ? 0 : Number($('f-service').value),
                    service: $('f-service').value === 'legacy' ? findById($('f-id').value).service : selectedOption.textContent,
                    stylist: $('f-stylist').value.trim(),
                    date: $('f-date').value, time: $('f-time').value, status: $('f-status').value,
                    price: Number($('f-price').value) || 0, notes: $('f-notes').value.trim()
                };
                var id = $('f-id').value;

                sendToPHP('save_appointment.php', Object.assign({ id: id }, data)).done(function (res) {
                    if (data.status === 'completed') {
                        modal.hide();
                        window.location.reload();
                        return;
                    }
                    if (id) { Object.assign(findById(id), data); }
                    else { data.id = Number(res); newId = data.id; list.push(data); }
                    modal.hide();
                    render();
                    showSaved(!!id);
                });
            });

            var confirmEl = document.getElementById('deleteModal');
            var confirmModal = bootstrap.Modal.getOrCreateInstance(confirmEl);
            var pendingDeleteId = null;
            var returnToAppointmentModal = false;

            /* Delete modal */
            $('btnDeleteAppt').addEventListener('click', function () {
                pendingDeleteId = $('f-id').value;
                returnToAppointmentModal = true;
                var a = findById(pendingDeleteId);
                $('deleteTarget').textContent = a ? a.client + ' (' + fmtDate(a.date) + ', ' + fmtTime(a.time) + ')' : 'this appointment';
                modal.hide();
                modalEl.addEventListener('hidden.bs.modal', function () { confirmModal.show(); }, { once: true });
            });

            /*j inupdate ko para madelete nya yung nasa database */
            $('btnConfirmDelete').addEventListener('click', function () {
                if (pendingDeleteId === null) return;      // IMPORTANT, see note below
                var id = pendingDeleteId;

                sendToPHP('delete_record.php', { table: 'appointments', id: id }).done(function () {
                    list = list.filter(function (a) { return String(a.id) !== String(id); });
                    pendingDeleteId = null;
                    returnToAppointmentModal = false;
                    confirmModal.hide();
                    render();
                });
            });

            confirmEl.addEventListener('hidden.bs.modal', function () {
                if (pendingDeleteId !== null && returnToAppointmentModal) {
                    modal.show();
                } else {
                    pendingDeleteId = null;
                }
            });

            render();
        })();  



        /*j added function for sending data to PHP */
        function sendToPHP(url, payload) {
            return jQuery.ajax({
                url: url,
                method: 'POST',
                data: payload,        // sent as normal form data
                dataType: 'text'      // PHP replies with plain text
            }).fail(function (xhr) {
                var msg = xhr.status === 400 ? xhr.responseText : 'Something went wrong. Please try again.';
                Swal.fire({ icon: 'error', title: 'Could not save', text: msg });
            });
        }

        function showSaved(isUpdate) {
            Swal.fire({
                icon: 'success',
                title: isUpdate ? 'Updated!' : 'Saved!',
                text: isUpdate ? 'The record was updated successfully.' : 'The record was saved successfully.',
                timer: 1800,
                showConfirmButton: false
            });
        }

    </script>

    <script>
        /*-----------Employee Team Data---------------*/
        (function () {
            var STATUS = {
                Owner: { label: 'Owner', badge: 'bg-warning-subtle text-warning-emphasis' },
                Employed: { label: 'Employed', badge: 'bg-success-subtle text-success-emphasis' },
                Resigned: { label: 'Resigned', badge: 'bg-info-subtle text-info-emphasis' },
                Terminated: { label: 'Terminated', badge: 'bg-danger-subtle text-danger-emphasis' },
                Retired: { label: 'Retired', badge: 'bg-secondary-subtle text-secondary-emphasis' }
            };

            function esc(s) {
                return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
                    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
                });
            }
            function fmtDate(d) {
                return d ? new Date(d + 'T00:00').toLocaleDateString([], { month: 'short', day: 'numeric' }) : '—';
            }

            /*j retrieving ng staff data */
            var list = [
            <?php while ($r = $staff->fetch_assoc()): ?>
                {
                    id:        <?= (int)$r['id'] ?>,
                    Employees: <?= js($r['name']) ?>,
                    status:    <?= js($r['status']) ?>,
                    date:      <?= js($r['date_employed']) ?>,
                    notes:     <?= js($r['notes']) ?>
                },
            <?php endwhile; ?>
            ];
            var nextId = 100, newId = null;

            var listEl = document.getElementById('empList');
            var emptyEl = document.getElementById('empEmpty');
            var searchEl = document.getElementById('empSearch');
            var statusFilterEl = document.getElementById('empStatusFilter');
            var countEl = document.getElementById('empListCount');
            var modalEl = document.getElementById('empModal');
            var modal = bootstrap.Modal.getOrCreateInstance(modalEl);
            var form = document.getElementById('empForm');
            var $ = function (id) { return document.getElementById(id); };

            function render() {
                var query = searchEl.value.trim().toLowerCase();
                var statusFilter = statusFilterEl.value;
                var shown = list.filter(function (e) {
                    var searchableText = [e.id, e.Employees, e.status, e.date, e.notes].join(' ').toLowerCase();
                    return searchableText.includes(query) && (statusFilter === 'All' || e.status === statusFilter);
                })
                    .sort(function (a, b) { return b.id - a.id; });

                listEl.innerHTML = shown.map(function (e) {
                    var s = STATUS[e.status] || STATUS.Employed;
                    var off = e.status === 'Terminated' || e.status === 'Retired' || e.status === 'Resigned';
                    var noteText = e.notes ? esc(e.notes) : 'No notes';
                    return '<div class="list-group-item d-flex flex-wrap flex-md-nowrap align-items-center gap-3 px-4 py-3">' +
                        '<div class="list-group-item-action d-flex flex-grow-1 align-items-center gap-3" style="min-width:0" data-employee-view="' + e.id + '" role="button" tabindex="0" aria-label="View staff member ' + esc(e.Employees) + '">' +
                        '<span class="time-pill' + (off ? ' opacity-50' : '') + '">' + fmtDate(e.date) + '</span>' +
                        '<div class="flex-grow-1"><div class="fw-semibold' + (off ? ' text-decoration-line-through text-body-secondary' : '') + '">' + esc(e.Employees) +
                        (e.id === newId ? ' <span class="badge text-bg-primary ms-1">New</span>' : '') + '</div>' +
                        '<small class="text-body-secondary">' + noteText + '</small></div>' +
                        '<div class="Huge text-end"><span class="badge rounded-pill ' + s.badge + '">' + s.label + '</span>' +
                        '</div></div><div class="d-flex flex-shrink-0 gap-1">' +
                        '<button type="button" class="btn btn-sm btn-outline-secondary rounded-pill" data-employee-edit="' + e.id + '" aria-label="Edit ' + esc(e.Employees) + '"><i class="bi bi-pencil me-1"></i>Edit</button>' +
                        '<button type="button" class="btn btn-sm btn-outline-danger rounded-pill" data-employee-delete="' + e.id + '" aria-label="Delete ' + esc(e.Employees) + '"><i class="bi bi-trash"></i></button>' +
                        '</div></div>';
                }).join('');

                emptyEl.classList.toggle('d-none', shown.length > 0);
                emptyEl.textContent = list.length
                    ? 'No staff found. Try another search or status.'
                    : 'No staff here yet. Add a staff member to get started.';
                countEl.textContent = 'Showing ' + shown.length + ' of ' + list.length + ' staff';
            }
            // Add or Edit modal if else
            function openModal(e, readOnly) {
                form.reset();
                Array.prototype.forEach.call(form.querySelectorAll('input:not([type="hidden"]), select, textarea'), function (field) {
                    field.disabled = false;
                });
                $('empModalTitle').textContent = readOnly ? 'View Staff' : (e ? 'Edit Staff' : 'Add Staff');
                $('btnDeleteEmp').classList.toggle('d-none', !e || readOnly);
                form.querySelector('button[type="submit"]').classList.toggle('d-none', !!readOnly);
                $('emp-id').value = e ? e.id : '';
                $('emp-Employees').value = e ? e.Employees : '';
                $('emp-status').value = e ? e.status : 'Employed';
                $('emp-date').value = e ? e.date : '';
                $('emp-notes').value = e ? e.notes : '';
                if (readOnly) {
                    Array.prototype.forEach.call(form.querySelectorAll('input:not([type="hidden"]), select, textarea'), function (field) {
                        field.disabled = true;
                    });
                }
                modal.show();
            }

            function findById(id) {
                return list.find(function (e) { return String(e.id) === String(id); }) || null;
            }

            $('btnNewEmp').addEventListener('click', function () { openModal(null, false); });

            function openFromCard(event) {
                var editButton = event.target.closest('[data-employee-edit]');
                var deleteButton = event.target.closest('[data-employee-delete]');
                if (editButton) {
                    var editedEmployee = findById(editButton.dataset.employeeEdit);
                    if (editedEmployee) openModal(editedEmployee, false);
                    return;
                }
                if (deleteButton) {
                    pendingDeleteId = deleteButton.dataset.employeeDelete;
                    returnToEmployeeModal = false;
                    var employeeToDelete = findById(pendingDeleteId);
                    $('deleteTarget').textContent = employeeToDelete ? employeeToDelete.Employees : 'this employee';
                    confirmModal.show();
                    return;
                }
                var card = event.target.closest('[data-employee-view]');
                if (card) openModal(findById(card.dataset.employeeView), true);
            }
            listEl.addEventListener('click', openFromCard);
            listEl.addEventListener('keydown', function (e) {
                if (e.target.closest('[data-employee-view]') && (e.key === 'Enter' || e.key === ' ')) {
                    if (e.key === ' ') e.preventDefault();
                    openFromCard(e);
                }
            });

            searchEl.addEventListener('input', render);
            statusFilterEl.addEventListener('change', render);

            /*j inupdate koto para everytime magsubmit nagsesend ng data sa php*/
            form.addEventListener('submit', function (e) {
                e.preventDefault();
                if (form.querySelector('button[type="submit"]').classList.contains('d-none')) return;
                var data = {
                    Employees: $('emp-Employees').value.trim(),
                    status: $('emp-status').value,
                    date: $('emp-date').value,
                    notes: $('emp-notes').value.trim()
                };
                var id = $('emp-id').value;

                sendToPHP('save_staff.php', Object.assign({ id: id }, data)).done(function (res) {
                    if (id) { Object.assign(findById(id), data); }
                    else { data.id = Number(res); newId = data.id; list.push(data); }
                    modal.hide();
                    render();
                    showSaved(!!id);
                });
            });

            var confirmEl = document.getElementById('deleteModal');
            var confirmModal = bootstrap.Modal.getOrCreateInstance(confirmEl);
            var pendingDeleteId = null;
            var returnToEmployeeModal = false;
            // Delete modal
            $('btnDeleteEmp').addEventListener('click', function () {
                pendingDeleteId = $('emp-id').value;
                returnToEmployeeModal = true;
                var e = findById(pendingDeleteId);
                $('deleteTarget').textContent = e ? e.Employees : 'this employee';
                modal.hide();
                modalEl.addEventListener('hidden.bs.modal', function () { confirmModal.show(); }, { once: true });
            });

            /* inupdate ko para madelete nya yung nasa database */
            $('btnConfirmDelete').addEventListener('click', function () {
                if (pendingDeleteId === null) return;      // IMPORTANT, see note below
                var id = pendingDeleteId;

                sendToPHP('delete_record.php', { table: 'staff', id: id }).done(function () {
                    list = list.filter(function (a) { return String(a.id) !== String(id); });
                    pendingDeleteId = null;
                    returnToEmployeeModal = false;
                    confirmModal.hide();
                    render();
                });
            });

            confirmEl.addEventListener('hidden.bs.modal', function () {
                if (pendingDeleteId !== null && returnToEmployeeModal) modal.show();
                else pendingDeleteId = null;
            });

            render();
        })();
    </script>

    <script>
         /*-----------Sales report---------------*/
        (function () {
            var STATUS = {
                completed: { label: 'Completed', bar: 'bg-info', badge: 'bg-info-subtle text-info-emphasis' },
                cancelled: { label: 'Cancelled', bar: 'bg-secondary', badge: 'bg-secondary-subtle text-secondary-emphasis' }
            };

            function esc(s) {
                return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
                    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
                });
            }
            function normalizeService(value) {
                return String(value || '').replace(/&/g, 'and').replace(/\s+/g, ' ').trim().toLowerCase();
            }
            function fmtTime(t) {
                if (!t) return '--:--';
                var dt = new Date('1970-01-01T' + t);
                return isNaN(dt.getTime()) ? '--:--' : dt.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
            }
            function fmtDate(d) {
                if (!d) return '';
                var date = new Date(d + 'T00:00');
                return isNaN(date.getTime()) ? '' : date.toLocaleDateString([], { month: 'short', day: 'numeric' });
            }

            /*j retrieving ng sales data */
            var list = [
            <?php while ($r = $sales->fetch_assoc()): ?>
                {
                    id:      <?= (int)$r['id'] ?>,
                    client:  <?= js($r['client']) ?>,
                    phone:   <?= js($r['phone']) ?>,
                    service: <?= js($r['service']) ?>,
                    service_category: <?= js($r['service_category'] ?? 'Haircut and Styling') ?>,
                    stylist: <?= js($r['stylist']) ?>,
                    date:    <?= js($r['sale_date']) ?>,
                    time:    <?= js($r['sale_time']) ?>,
                    status:  <?= js($r['status']) ?>,
                    price:   <?= (float)$r['price'] ?>,
                    notes:   <?= js($r['notes']) ?>
                },
            <?php endwhile; ?>
            ];
            var filter = 'ALL';

            var listEl = document.getElementById('saleList');
            var emptyEl = document.getElementById('saleEmpty');
            var searchEl = document.getElementById('saleSearch');
            var categoryFilterEl = document.getElementById('saleCategoryFilter');
            var canManageReports = <?= $canManageReports ? 'true' : 'false' ?>;
            var serviceInput = document.getElementById('sale-service');
            var walkInServiceSelect = document.getElementById('walkInServiceSelect');
            var serviceLabel = document.querySelector('label[for="sale-service"]');
            var activeServices = (window.dashboardServices || []).filter(function (service) {
                return service.status === 'Active';
            });
            activeServices.forEach(function (service) {
                var option = document.createElement('option');
                option.value = service.name;
                option.textContent = service.name;
                walkInServiceSelect.appendChild(option);
            });

            function render() {
                var query = searchEl.value.trim().toLowerCase();
                filter = categoryFilterEl.value;
                var shown = list.filter(function (a) {
                    var category = a.service_category || a.service;
                    var matchesFilter = filter === 'ALL' || normalizeService(category) === normalizeService(filter) || normalizeService(a.service) === normalizeService(filter);
                    var searchableText = [a.id, a.client, a.phone, a.service, category, a.stylist, a.date, a.time, a.status, a.price, a.notes].join(' ').toLowerCase();
                    return matchesFilter && searchableText.includes(query);
                }).sort(function (a, b) { return b.id - a.id; });

                listEl.innerHTML = shown.map(function (a) {
                    var s = STATUS[a.status] || STATUS.completed;
                    var off = a.status === 'cancelled';
                    return '<div class="list-group-item d-flex flex-wrap flex-md-nowrap align-items-center gap-3 px-4 py-3">' +
                        '<div class="list-group-item-action d-flex flex-grow-1 align-items-center gap-3" style="min-width:0" data-sale-view="' + a.id + '" role="button" tabindex="0" aria-label="View sale for ' + esc(a.client) + '">' +
                        '<span class="time-pill' + (off ? ' opacity-50' : '') + '">' + fmtDate(a.date) + ', ' + fmtTime(a.time) + '</span>' +
                        '<div class="flex-grow-1"><div class="fw-semibold' + (off ? ' text-decoration-line-through text-body-secondary' : '') + '">' + esc(a.client) +
                        '</div>' +
                        '<small class="text-body-secondary">' + esc(a.service) + (a.stylist ? ' &middot; ' + esc(a.stylist) : '') + '</small></div>' +
                        '<div class="medium text-end"><span class="badge rounded-pill ' + s.badge + '">' + s.label + '</span>' +
                        '<div class="medium text-body-secondary mt-1">' + ('₱' + Number(a.price || 0).toLocaleString('en-PH')) + '</div></div></div>' +
                        (canManageReports ? '<div class="d-flex flex-shrink-0 gap-1">' +
                            '<button type="button" class="btn btn-sm btn-outline-secondary rounded-pill sale-edit" data-id="' + a.id + '" aria-label="Edit sale for ' + esc(a.client) + '"><i class="bi bi-pencil me-1"></i>Edit</button>' +
                            '<button type="button" class="btn btn-sm btn-outline-danger rounded-pill sale-delete" data-id="' + a.id + '" aria-label="Delete sale for ' + esc(a.client) + '"><i class="bi bi-trash"></i></button>' +
                            '</div>' : '') + '</div>';
                }).join('');

                emptyEl.textContent = list.length ? 'No sales match your search or category.' : 'No Sales here yet.';
                emptyEl.classList.toggle('d-none', shown.length > 0);
            }

            categoryFilterEl.addEventListener('change', render);
            searchEl.addEventListener('input', render);

            render();

            var saleModalEl = document.getElementById('saleModal');
            var saleModal = bootstrap.Modal.getOrCreateInstance(saleModalEl);
            var saleForm = document.getElementById('saleForm');
            var addWalkInButton = document.getElementById('addWalkInSale');

            function setSaleFormReadOnly(readOnly) {
                Array.prototype.forEach.call(saleForm.querySelectorAll('input:not([type="hidden"]), select, textarea'), function (field) {
                    field.disabled = !!readOnly;
                });
                saleForm.querySelector('button[type="submit"]').classList.toggle('d-none', !!readOnly);
            }

            function setWalkInServiceControl(isWalkIn) {
                serviceInput.classList.toggle('d-none', isWalkIn);
                serviceInput.disabled = isWalkIn;
                serviceInput.required = !isWalkIn;
                walkInServiceSelect.classList.toggle('d-none', !isWalkIn);
                walkInServiceSelect.disabled = !isWalkIn;
                walkInServiceSelect.required = isWalkIn;
                serviceLabel.htmlFor = isWalkIn ? 'walkInServiceSelect' : 'sale-service';
            }

            function openSale(sale, readOnly) {
                if (!sale || (!canManageReports && !readOnly)) return;
                document.getElementById('saleModalTitle').textContent = readOnly ? 'View sale' : 'Edit sale';
                saleModalEl.querySelector('.modal-header p').textContent = readOnly ? 'Sale details.' : 'Update the completed sale details.';
                document.getElementById('sale-client').readOnly = false;
                document.getElementById('sale-id').value = sale.id;
                document.getElementById('sale-client').value = sale.client;
                document.getElementById('sale-phone').value = sale.phone || '';
                document.getElementById('sale-service').value = sale.service;
                document.getElementById('sale-stylist').value = sale.stylist || '';
                document.getElementById('sale-service-category').value = sale.service_category || '';
                document.getElementById('sale-date').value = sale.date;
                document.getElementById('sale-time').value = sale.time;
                document.getElementById('sale-status').value = sale.status;
                document.getElementById('sale-price').value = sale.price;
                document.getElementById('sale-notes').value = sale.notes || '';
                setWalkInServiceControl(false);
                setSaleFormReadOnly(readOnly);
                saleModal.show();
            }

            if (addWalkInButton) {
                addWalkInButton.addEventListener('click', function () {
                    saleForm.reset();
                    document.getElementById('saleModalTitle').textContent = 'Add walk-in sale';
                    saleModalEl.querySelector('.modal-header p').textContent = 'Record a completed sale for a walk-in client.';
                    document.getElementById('sale-id').value = '';
                    document.getElementById('sale-client').value = 'Walk-in';
                    document.getElementById('sale-client').readOnly = true;
                    document.getElementById('sale-status').value = 'completed';
                    var now = new Date();
                    document.getElementById('sale-date').value =
                        now.getFullYear() + '-' + String(now.getMonth() + 1).padStart(2, '0') + '-' + String(now.getDate()).padStart(2, '0');
                    document.getElementById('sale-time').value =
                        String(now.getHours()).padStart(2, '0') + ':' + String(now.getMinutes()).padStart(2, '0');
                    setSaleFormReadOnly(false);
                    setWalkInServiceControl(true);
                    document.getElementById('sale-status').disabled = true;
                    saleModal.show();
                });
            }

            function applySelectedService(selectedService) {
                if (selectedService) {
                    document.getElementById('sale-price').value = selectedService.price;
                    document.getElementById('sale-service-category').value = selectedService.category;
                }
            }

            serviceInput.addEventListener('change', function () {
                applySelectedService(activeServices.find(function (service) { return service.name === serviceInput.value; }));
            });
            walkInServiceSelect.addEventListener('change', function () {
                applySelectedService(activeServices.find(function (service) { return service.name === walkInServiceSelect.value; }));
            });

            listEl.addEventListener('click', function (e) {
                    var editButton = e.target.closest('.sale-edit');
                    var deleteButton = e.target.closest('.sale-delete');
                    if (editButton) {
                        var sale = list.find(function (item) { return String(item.id) === editButton.dataset.id; });
                        if (sale) openSale(sale, false);
                        return;
                    }
                    if (deleteButton) {
                        var saleToDelete = list.find(function (item) { return String(item.id) === deleteButton.dataset.id; });
                        if (!saleToDelete) return;
                        Swal.fire({
                            icon: 'warning',
                            title: 'Delete this sale?',
                            text: saleToDelete.client + ' · ' + saleToDelete.service,
                            showCancelButton: true,
                            confirmButtonText: 'Delete',
                            confirmButtonColor: '#dc3545',
                            cancelButtonText: 'Cancel'
                        }).then(function (result) {
                            if (!result.isConfirmed) return;
                            sendToPHP('delete_record.php', { table: 'sales', id: saleToDelete.id }).done(function () {
                                list = list.filter(function (item) { return String(item.id) !== String(saleToDelete.id); });
                                render();
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Deleted!',
                                    text: 'The sale was deleted successfully.',
                                    timer: 1800,
                                    showConfirmButton: false
                                });
                            });
                        });
                        return;
                    }
                    var saleView = e.target.closest('[data-sale-view]');
                    if (saleView) {
                        var selectedSale = list.find(function (item) { return String(item.id) === saleView.dataset.saleView; });
                        if (selectedSale) openSale(selectedSale, true);
                    }
            });
            listEl.addEventListener('keydown', function (e) {
                if (e.target.matches('[data-sale-view]') && (e.key === 'Enter' || e.key === ' ')) {
                    e.preventDefault();
                    var selectedSale = list.find(function (item) { return String(item.id) === e.target.dataset.saleView; });
                    if (selectedSale) openSale(selectedSale, true);
                }
            });

            if (canManageReports) {
                saleForm.addEventListener('submit', function (e) {
                    e.preventDefault();
                    if (saleForm.querySelector('button[type="submit"]').classList.contains('d-none')) return;
                    var id = document.getElementById('sale-id').value;
                    var serviceName = (id ? serviceInput.value : walkInServiceSelect.value).trim();
                    var saleServiceCategory = document.getElementById('sale-service-category').value.trim();
                    var matchingService = activeServices.find(function (service) { return service.name === serviceName; });
                    var data = {
                        id: id,
                        client: document.getElementById('sale-client').value.trim(),
                        phone: document.getElementById('sale-phone').value.trim(),
                        service: serviceName,
                        service_category: matchingService ? matchingService.category : saleServiceCategory,
                        stylist: document.getElementById('sale-stylist').value.trim(),
                        date: document.getElementById('sale-date').value,
                        time: document.getElementById('sale-time').value,
                        status: document.getElementById('sale-status').value,
                        price: document.getElementById('sale-price').value,
                        notes: document.getElementById('sale-notes').value.trim()
                    };
                    sendToPHP('save_sale.php', data).done(function (response) {
                        var sale = list.find(function (item) { return String(item.id) === String(id); });
                        if (sale) {
                            sale.client = data.client;
                            sale.phone = data.phone;
                            sale.service = data.service;
                            sale.service_category = data.service_category;
                            sale.stylist = data.stylist;
                            sale.date = data.date;
                            sale.time = data.time;
                            sale.status = data.status;
                            sale.price = Number(data.price);
                            sale.notes = data.notes;
                        } else if (!id) {
                            data.id = Number(response);
                            list.push(data);
                        }
                        saleModal.hide();
                        render();
                        showSaved(!!id);
                    });
                });
            }
        })();  
    </script>

    <style>
        .client-stat-icon{width:52px;height:52px;border-radius:16px;display:flex;align-items:center;justify-content:center;flex-shrink:0}
        .client-search-wrap{position:relative;width:100%;max-width:360px}
        .client-search-wrap .bi-search{position:absolute;left:14px;top:50%;transform:translateY(-50%);color:#6c757d;pointer-events:none}
        .client-search-wrap input{padding-left:40px;border-radius:12px;min-height:42px}
        #view-clients .table thead th{font-size:.75rem;text-transform:uppercase;letter-spacing:.04em;color:#6c757d;font-weight:600;white-space:nowrap;border-bottom-color:#e9ecef}
        #view-clients .table td{padding-top:14px;padding-bottom:14px}
        .client-avatar{width:40px;height:40px;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;background:#f0e8e1;color:#70513d;font-weight:700;flex-shrink:0}
        @media(max-width:575.98px){#view-clients .table{min-width:650px}.client-search-wrap{max-width:none}}
    </style>

    <script>
    /* Client Management */
    (function () {
        var clients = window.dashboardClients;

        var nextId = clients.reduce(function (max, c) { return Math.max(max, Number(c.id)||0); }, 0) + 1;
        var editingId = null, deletingId = null;
        var modalEl = document.getElementById('clientModal');
        var deleteModalEl = document.getElementById('clientDeleteModal');
        if (!modalEl || !deleteModalEl) return;
        var modal = bootstrap.Modal.getOrCreateInstance(modalEl);
        var deleteModal = bootstrap.Modal.getOrCreateInstance(deleteModalEl);
        var form = byId('clientForm');
        var isSaving = false;
        var submitButton = form.querySelector('button[type="submit"]');
        function byId(id) { return document.getElementById(id); }
        function escapeHtml(value) { return String(value == null ? '' : value).replace(/[&<>"']/g, function (c) { return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
        function notifyClientsUpdated() {
            window.dashboardClients = clients;
            window.dispatchEvent(new CustomEvent('clients-updated', { detail: clients }));
        }
        function formatDate(value) { if (!value) return '—'; var d = new Date(value + 'T00:00:00'); return isNaN(d.getTime()) ? '—' : d.toLocaleDateString([], {month:'short',day:'numeric',year:'numeric'}); }
        function initials(name) { return String(name||'?').trim().split(/\s+/).slice(0,2).map(function (part) { return part.charAt(0); }).join('').toUpperCase(); }
        function updateMonthTotals() {
            var now = new Date();
            var monthCount = clients.filter(function(c) {
                var d = new Date((c.createdAt || '') + 'T00:00:00');
                return !isNaN(d.getTime()) && d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
            }).length;
            byId('clientMonthTotal').textContent = monthCount;
            byId('overviewClientsNew').textContent = monthCount;
        }
        function scheduleMonthRefresh() {
            var now = new Date();
            var nextMonth = new Date(now.getFullYear(), now.getMonth() + 1, 1);
            window.setTimeout(function () {
                updateMonthTotals();
                scheduleMonthRefresh();
            }, Math.min(nextMonth.getTime() - now.getTime() + 50, 24 * 60 * 60 * 1000));
        }
        document.addEventListener('visibilitychange', function () {
            if (!document.hidden) updateMonthTotals();
        });
        scheduleMonthRefresh();
        function render() {
            var query = byId('clientSearch').value.trim().toLowerCase();
            var shown = clients.filter(function (c) { return [c.name,c.phone,c.email].join(' ').toLowerCase().indexOf(query) !== -1; }).sort(function (a,b) { return a.name.localeCompare(b.name); });
            byId('clientTableBody').innerHTML = shown.map(function (c) {
                return '<tr data-client-view="'+escapeHtml(c.id)+'" tabindex="0"><td><div class="d-flex align-items-center gap-3"><span class="client-avatar">'+escapeHtml(initials(c.name))+'</span><div><div class="fw-semibold">'+escapeHtml(c.name)+'</div><div class="small text-body-secondary">Client #'+escapeHtml(c.id)+'</div></div></div></td>'+
                '<td class="text-nowrap">'+escapeHtml(c.phone||'—')+'</td><td>'+escapeHtml(c.email||'—')+'</td><td class="text-nowrap">'+escapeHtml(formatDate(c.createdAt))+'</td>'+
                '<td class="text-end text-nowrap"><button type="button" class="btn btn-sm btn-outline-secondary rounded-pill me-1" data-client-edit="'+escapeHtml(c.id)+'" aria-label="Edit '+escapeHtml(c.name)+'"><i class="bi bi-pencil me-1"></i>Edit</button> <button type="button" class="btn btn-sm btn-outline-danger rounded-pill" data-client-delete="'+escapeHtml(c.id)+'" aria-label="Delete '+escapeHtml(c.name)+'"><i class="bi bi-trash"></i></button></td></tr>';
            }).join('');
            byId('clientEmptyState').classList.toggle('d-none', shown.length !== 0);
            byId('clientListCount').textContent = 'Showing ' + shown.length + ' of ' + clients.length + ' client' + (clients.length === 1 ? '' : 's');
            byId('clientTotal').textContent = clients.length;
            byId('clientContactTotal').textContent = clients.filter(function(c){return !!(c.phone || c.email);}).length;
            updateMonthTotals();
        }
        function openForm(client, readOnly) {
            editingId = client ? client.id : null;
            byId('clientModalTitle').textContent = readOnly ? 'View client' : (client ? 'Edit client' : 'Add client');
            byId('clientId').value = client ? client.id : '';
            byId('clientName').value = client ? client.name : '';
            byId('clientPhone').value = client ? client.phone : '';
            byId('clientEmail').value = client ? client.email : '';
            byId('clientNotes').value = client ? client.notes : '';
            Array.prototype.forEach.call(form.querySelectorAll('input:not([type="hidden"]), textarea'), function (field) {
                field.disabled = !!readOnly;
            });
            submitButton.classList.toggle('d-none', !!readOnly);
            modal.show();
        }
        byId('clientAddBtn').addEventListener('click', function(){openForm(null);});
        byId('clientSearch').addEventListener('input', render);
        byId('clientTableBody').addEventListener('click', function(e){
            var edit = e.target.closest('[data-client-edit]');
            var del = e.target.closest('[data-client-delete]');
            if (edit) { var found = clients.find(function(c){return String(c.id)===edit.dataset.clientEdit;}); if(found) openForm(found, false); return; }
            if (del) { deletingId = del.dataset.clientDelete; deleteModal.show(); return; }
            var row = e.target.closest('[data-client-view]');
            if (row) {
                var client = clients.find(function(c){return String(c.id)===row.dataset.clientView;});
                if (client) openForm(client, true);
            }
        });
        byId('clientTableBody').addEventListener('keydown', function(e) {
            if (e.target.matches('[data-client-view]') && (e.key === 'Enter' || e.key === ' ')) {
                e.preventDefault();
                var client = clients.find(function(c){return String(c.id)===e.target.dataset.clientView;});
                if (client) openForm(client, true);
            }
        });

        /*j inupdate koto para everytime magsubmit nagsesend ng data sa php*//*j inupdate koto */
        form.addEventListener('submit', function (e) {
            e.preventDefault();
            if (isSaving || submitButton.classList.contains('d-none')) return;
            var name = byId('clientName').value.trim(),
                phone = byId('clientPhone').value.trim(),
                email = byId('clientEmail').value.trim(),
                notes = byId('clientNotes').value.trim();
            if (!name || !phone) { return; }

            isSaving = true;
            submitButton.disabled = true;
            sendToPHP('save_client.php', { id: editingId, name: name, phone: phone, email: email, notes: notes }).done(function (res) {
                var existing = editingId === null ? null : clients.find(function (c) { return String(c.id) === String(editingId); });
                var t = new Date();
                var todayStr = t.getFullYear() + '-' + String(t.getMonth() + 1).padStart(2, '0') + '-' + String(t.getDate()).padStart(2, '0');
                var record = {
                    id: existing ? existing.id : Number(res),
                    name: name, phone: phone, email: email, notes: notes,
                    createdAt: existing ? existing.createdAt : todayStr
                };
                if (existing) clients = clients.map(function (c) { return c.id === existing.id ? record : c; });
                else clients.push(record);
                notifyClientsUpdated();
                render(); modal.hide();
                showSaved(!!existing);
            }).always(function () {
                isSaving = false;
                submitButton.disabled = false;
            });
        });

        /*j inupdate koto para magdelete sa db */
        byId('clientConfirmDelete').addEventListener('click', function () {
            var id = deletingId;
            sendToPHP('delete_record.php', { table: 'clients', id: id }).done(function () {
                clients = clients.filter(function (c) { return String(c.id) !== String(id); });
                notifyClientsUpdated();
                deletingId = null;
                render();
                deleteModal.hide();
            });
        });
        render();
    })();
    </script>


    <script>
    // SERVICES FRONT-END DEMO
    // This script manages the interface only.
    (function () {
        var canManageServices = <?= json_encode($canManageServices) ?>;
        var storageKey = 'ldrProgServicesV1';
        var services = [];
        var nextId = 1;
        var editingId = null;
        var deletingId = null;
        var serviceModal = bootstrap.Modal.getOrCreateInstance(document.getElementById('serviceModal'));
        var deleteModal = bootstrap.Modal.getOrCreateInstance(document.getElementById('serviceDeleteModal'));
        function el(id) { return document.getElementById(id); }
        function escapeHtml(value) {
            return String(value == null ? '' : value).replace(/[&<>"']/g, function (char) {
                return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char];
            });
        }
        function money(value) { return '₱' + Number(value || 0).toLocaleString('en-PH', {minimumFractionDigits:2, maximumFractionDigits:2}); }
        function saveServices() { localStorage.setItem(storageKey, JSON.stringify(services)); }
        
        /*j retrieving ng services data and tinanggal ko din yung localstorage */
        function loadServices() {
            services = [
        <?php foreach ($serviceRows as $r): ?>
                {
                    id:          <?= (int)$r['id'] ?>,
                    name:        <?= js($r['name']) ?>,
                    category:    <?= js($r['category']) ?>,
                    price:       <?= (float)$r['price'] ?>,
                    duration:    <?= (int)$r['duration'] ?>,
                    status:      <?= js($r['status']) ?>,
                    description: <?= js($r['description']) ?>
                },
        <?php endforeach; ?>
            ];
            nextId = services.reduce(function (max, s) { return Math.max(max, Number(s.id) || 0); }, 0) + 1;
        }

    
        function renderServices() {
            var query = el('serviceSearch').value.trim().toLowerCase();
            var category = el('serviceCategoryFilter').value;
            var filtered = services.filter(function (service) {
                var text = [service.name, service.category, service.description, service.id].join(' ').toLowerCase();
                return text.includes(query) && (category === 'All' || service.category === category);
            });
            el('serviceTotal').textContent = services.length;
            el('serviceActiveTotal').textContent = services.filter(function (s) { return s.status === 'Active'; }).length;
            var average = services.length ? services.reduce(function (sum, s) { return sum + Number(s.price || 0); }, 0) / services.length : 0;
            el('serviceAverage').textContent = money(average);
            if (!filtered.length) {
                el('serviceTableBody').innerHTML = '<tr><td colspan="7" class="text-center text-body-secondary py-5">No services found. Try another search or add a service.</td></tr>';
                return;
            }
            el('serviceTableBody').innerHTML = filtered.map(function (s) {
                var badge = s.status === 'Active' ? 'bg-success-subtle text-success-emphasis' : 'bg-secondary-subtle text-secondary-emphasis';
                var actions = canManageServices
                    ? '<button type="button" class="btn btn-sm btn-outline-secondary rounded-pill me-1" data-service-edit="' + escapeHtml(s.id) + '"><i class="bi bi-pencil me-1"></i>Edit</button><button type="button" class="btn btn-sm btn-outline-danger rounded-pill" data-service-delete="' + escapeHtml(s.id) + '" aria-label="Delete ' + escapeHtml(s.name) + '"><i class="bi bi-trash"></i></button>'
                    : '';
                return '<tr data-service-view="' + escapeHtml(s.id) + '" tabindex="0">' +
                    '<td><div class="fw-semibold">' + escapeHtml(s.name) + '</div><div class="small text-body-secondary">' + escapeHtml(s.description || 'No description') + '</div></td>' +
                    '<td><span class="text-body-secondary">SVC-' + String(s.id).padStart(3, '0') + '</span></td>' +
                    '<td>' + escapeHtml(s.category) + '</td>' +
                    '<td class="fw-semibold">' + money(s.price) + '</td>' +
                    '<td>' + escapeHtml(s.duration) + ' min</td>' +
                    '<td><span class="badge rounded-pill ' + badge + '">' + escapeHtml(s.status) + '</span></td>' +
                    '<td class="text-end text-nowrap">' + actions + '</td>' +
                    '</tr>';
            }).join('');
        }

        function openServiceForm(service, readOnly) {
            if (!canManageServices && !readOnly) return;
            editingId = service ? service.id : null;
            el('serviceModalTitle').textContent = readOnly ? 'View service' : (service ? 'Edit service' : 'Add service');
            el('serviceName').value = service ? service.name : '';
            el('serviceCategory').value = service ? service.category : 'Haircut and Styling';
            el('servicePrice').value = service ? service.price : '';
            el('serviceDuration').value = service ? service.duration : 30;
            el('serviceStatus').value = service ? service.status : 'Active';
            el('serviceDescription').value = service ? (service.description || '') : '';
            Array.prototype.forEach.call(el('serviceForm').querySelectorAll('input, select, textarea'), function (field) {
                field.disabled = !!readOnly;
            });
            el('serviceForm').querySelector('button[type="submit"]').classList.toggle('d-none', !!readOnly);
            serviceModal.show();
        }
        el('serviceAddBtn').addEventListener('click', function () { openServiceForm(null, false); });
        el('serviceSearch').addEventListener('input', renderServices);
        el('serviceCategoryFilter').addEventListener('change', renderServices);
        el('serviceTableBody').addEventListener('click', function (event) {
            var editButton = event.target.closest('[data-service-edit]');
            var deleteButton = event.target.closest('[data-service-delete]');
            if (editButton) {
                var selected = services.find(function (s) { return String(s.id) === editButton.dataset.serviceEdit; });
                if (selected) openServiceForm(selected, false);
                return;
            }
            if (deleteButton) {
                deletingId = deleteButton.dataset.serviceDelete;
                deleteModal.show();
                return;
            }
            var row = event.target.closest('[data-service-view]');
            if (row) {
                var service = services.find(function (s) { return String(s.id) === row.dataset.serviceView; });
                if (service) openServiceForm(service, true);
            }
        });
        el('serviceTableBody').addEventListener('keydown', function (event) {
            if (event.target.matches('[data-service-view]') && (event.key === 'Enter' || event.key === ' ')) {
                event.preventDefault();
                var service = services.find(function (s) { return String(s.id) === event.target.dataset.serviceView; });
                if (service) openServiceForm(service, true);
            }
        });

        /*j inupdate koto para everytime magsubmit nagsesend ng data sa php*/
        el('serviceForm').addEventListener('submit', function (event) {
            event.preventDefault();
            if (el('serviceForm').querySelector('button[type="submit"]').classList.contains('d-none')) return;
            var name = el('serviceName').value.trim();
            var price = Number(el('servicePrice').value);
            var duration = Number(el('serviceDuration').value);
            if (!name || !Number.isFinite(price) || price < 0 || !Number.isFinite(duration) || duration < 5) return;

            var data = { name: name, category: el('serviceCategory').value, price: price, duration: duration,
                        status: el('serviceStatus').value, description: el('serviceDescription').value.trim() };

            sendToPHP('save_service.php', Object.assign({ id: editingId }, data)).done(function (res) {
                var record = Object.assign({ id: editingId === null ? Number(res) : editingId }, data);
                if (editingId === null) services.push(record);
                else services = services.map(function (s) { return String(s.id) === String(editingId) ? record : s; });
                window.dispatchEvent(new CustomEvent('services-updated', { detail: services }));
                renderServices(); serviceModal.hide();
                showSaved(editingId !== null);
            });
        });

        /*j inupdate ko to para magdelete sa db */
        el('serviceConfirmDelete').addEventListener('click', function () {
            var id = deletingId;
            sendToPHP('delete_record.php', { table: 'services', id: id }).done(function () {
                services = services.filter(function (s) { return String(s.id) !== String(id); });
                window.dispatchEvent(new CustomEvent('services-updated', { detail: services }));
                deletingId = null;
                renderServices();
                deleteModal.hide();
            });
        });
        loadServices();
        renderServices();
    })();
    </script>

</body>
</html>