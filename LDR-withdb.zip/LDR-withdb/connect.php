<?php

$db_server = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "ldrsalonspa_db";
$error = "";

try {
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

    $conn = mysqli_connect(
        $db_server,
        $db_user,
        $db_pass,
        $db_name
    );

    date_default_timezone_set('Asia/Manila');
    $conn->query("SET time_zone = '+08:00'");

} catch (mysqli_sql_exception $e) {
    $error = "Could not connect!";
    echo $error;
}

?>