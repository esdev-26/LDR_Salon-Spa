<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liny Delos Reyes Salon & Spa</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="bootstrap-icons-1.13.1/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/dashboard.css">
    <link rel="icon" href="Logo/circular-logo.png" type="image/png">
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/jquery-4.0.0.min.js"></script>
</head>
<body class="d-flex flex-column min-vh-100">
    <nav class="navbar fixed-top bg-body-tertiary border-bottom py-0">
        <div class="container-fluid px-3">
            <div class="d-flex align-items-center gap-3 me-auto">
                <button class="navbar-toggler menu-btn px-2 d-lg-none" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="brand-block d-lg-block">
                    <div class="date-label" id="dateLabel"></div>
                    <a class="navbar-brand mb-0" href="#">Home</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="offcanvas-lg offcanvas-start text-white" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
        <div class="offcanvas-header">
            <div class="col d-flex align-items-center gap-3">
                <img src="Logo/circular-logo.png" alt="Liny Delos Reyes Logo" class="img-fluid" style="max-height: 52px;">
                <div class="col">
                    <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Liny Delos Reyes</h5>
                    <h6 class="offcanvas-title">Salon & Spa</h6>
                </div>
            </div>
            <div class="col-auto d-flex flex-column align-items-end">
                <button type="button" class="btn-close btn-close-white d-lg-none" data-bs-dismiss="offcanvas" data-bs-target="#offcanvasNavbar" aria-label="Close"></button>
            </div>
        </div>
        <div class="offcanvas-body d-flex flex-column">
            <div class="container flex-grow-1">
                <div class="d-flex flex-column flex-shrink-0 p-3 text-white" >
                    <span class="fs-6 text-uppercase text-white mb-2">Workspace</span>
                    <ul class="nav nav-pills flex-column mb-auto">
                        <li class="nav-item mb-1">
                            <a href="#" class="nav-link text-white active" id="link-overview">
                                <i class="bi bi-grid me-2"></i> Overview
                            </a>
                        </li>
                        <li class="nav-item mb-1">
                            <a href="#" class="nav-link text-white" id="link-appointments">
                                <i class="bi bi-calendar-event me-2"></i> Appointments
                            </a>
                        </li>
                        <li class="nav-item mb-1">
                            <a href="#" class="nav-link text-white" id="link-clients">
                                <i class="bi bi-people me-2"></i> Clients
                            </a>
                        </li>
                        <li class="nav-item mb-1">
                            <a href="#" class="nav-link text-white" id="link-services">
                                <i class="bi bi-scissors me-2"></i> Services
                            </a>
                        </li>
                        <li class="nav-item mb-1">
                            <a href="#" class="nav-link text-white" id="link-team">
                                <i class="bi bi-person me-2"></i> Team
                            </a>
                        </li>
                        <li class="nav-item mb-1">
                            <a href="#" class="nav-link text-white" id="link-reports">
                                <i class="bi bi-activity me-2"></i> Reports
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
             <div class="px-3 pt-3 pb-3 border-top mt-auto">
                <a href="#" class="btn border btn-lg w-100 rounded-pill shadow-sm d-inline-flex align-items-center justify-content-center gap-2 fw-semibold text-uppercase fs-6 text-white" onclick="window.location.href='home.php';">
                    <i class="bi bi-box-arrow-right"></i>
                    Sign Out
                </a>
            </div>
        </div>
    </div>

    <main class="app-main flex-grow-1 p-4 bg-body-secondary">
        <section class="view" id="view-overview">
            <div class="mb-4">
                <h1 class="h3 mb-1">Overview</h1>
                <p class="text-body-secondary mb-0">Here's how the salon is doing today.</p>
            </div>
            <div class="row row-cols-1 row-cols-sm-2 row-cols-xl-4 g-4 mb-4">
                <div class="col">
                    <div class="card stat-card stat-card-featured border-0 shadow-sm rounded-4 h-100">
                        <div class="card-body p-4">
                            <div class="d-flex justify-content-between align-items-start mb-4">
                                <span class="stat-label">Today's appointments</span>
                                <span class="stat-icon d-inline-flex align-items-center justify-content-center"><i class="bi bi-calendar-check"></i></span>
                            </div>
                            <div class="stat-value mb-2">12</div>
                            <small class="stat-label">9 booked &middot; 3 walk-ins</small>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card stat-card border-0 shadow-sm rounded-4 h-100">
                        <div class="card-body p-4">
                            <div class="d-flex justify-content-between align-items-start mb-4">
                                <span class="stat-label">Total clients</span>
                                <span class="stat-icon d-inline-flex align-items-center justify-content-center"><i class="bi bi-people"></i></span>
                            </div>
                            <div class="stat-value mb-2">248</div>
                            <small class="text-success fw-semibold"><i class="bi bi-arrow-up-short"></i>8 new this month</small>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card stat-card border-0 shadow-sm rounded-4 h-100">
                        <div class="card-body p-4">
                            <div class="d-flex justify-content-between align-items-start mb-4">
                                <span class="stat-label">Sales today</span>
                                <span class="stat-icon d-inline-flex align-items-center justify-content-center"><i class="bi bi-wallet2"></i></span>
                            </div>
                            <div class="stat-value mb-2">&#8369;18,450</div>
                            <small class="stat-label">14 services completed</small>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card stat-card border-0 shadow-sm rounded-4 h-100">
                        <div class="card-body p-4">
                            <div class="d-flex justify-content-between align-items-start mb-4">
                                <span class="stat-label">Pending requests</span>
                                <span class="stat-icon d-inline-flex align-items-center justify-content-center"><i class="bi bi-hourglass-split"></i></span>
                            </div>
                            <div class="stat-value mb-2">5</div>
                            <small class="stat-label">Waiting for confirmation</small>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row g-4">
                <div class="col-12 col-lg-7">
                    <div class="card border-0 shadow-sm rounded-4 h-100">
                        <div class="card-body p-4">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h2 class="h5 mb-0">Upcoming appointments</h2>
                                <a href="#" id="view-all" class="small link-dark fw-semibold">View all</a>
                            </div>
                            <div class="appt-row d-flex align-items-center gap-3 py-3">
                                <span class="time-pill">10:00 AM</span>
                                <div class="flex-grow-1">
                                    <div class="fw-semibold">Maria Santos</div>
                                    <small class="text-body-secondary">Hair color</small>
                                </div>
                                <span class="badge rounded-pill bg-success-subtle text-success-emphasis">Confirmed</span>
                            </div>
                            <div class="appt-row d-flex align-items-center gap-3 py-3">
                                <span class="time-pill">11:30 AM</span>
                                <div class="flex-grow-1">
                                    <div class="fw-semibold">Ana Reyes</div>
                                    <small class="text-body-secondary">Facial</small>
                                </div>
                                <span class="badge rounded-pill bg-warning-subtle text-warning-emphasis">Pending</span>
                            </div>
                            <div class="appt-row d-flex align-items-center gap-3 py-3">
                                <span class="time-pill">1:00 PM</span>
                                <div class="flex-grow-1">
                                    <div class="fw-semibold">Joy Dela Cruz</div>
                                    <small class="text-body-secondary">Massage (60 min)</small>
                                </div>
                                <span class="badge rounded-pill bg-success-subtle text-success-emphasis">Confirmed</span>
                            </div>
                            <div class="appt-row d-flex align-items-center gap-3 py-3">
                                <span class="time-pill">3:00 PM</span>
                                <div class="flex-grow-1">
                                    <div class="fw-semibold">Liza Mendoza</div>
                                    <small class="text-body-secondary">Haircut and styling</small>
                                </div>
                                <span class="badge rounded-pill bg-warning-subtle text-warning-emphasis">Pending</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-lg-5">
                    <div class="card border-0 shadow-sm rounded-4 h-100">
                        <div class="card-body p-4">
                            <h2 class="h5 mb-4">Popular services this month</h2>
                            <div class="mb-4">
                                <div class="d-flex justify-content-between small mb-2"><span class="fw-semibold">Haircut and styling</span><span class="text-body-secondary">42</span></div>
                                <div class="progress"><div class="progress-bar bg-brown" style="width: 84%"></div></div>
                            </div>
                            <div class="mb-4">
                                <div class="d-flex justify-content-between small mb-2"><span class="fw-semibold">Massage</span><span class="text-body-secondary">31</span></div>
                                <div class="progress"><div class="progress-bar bg-brown" style="width: 62%"></div></div>
                            </div>
                            <div class="mb-4">
                                <div class="d-flex justify-content-between small mb-2"><span class="fw-semibold">Hair color</span><span class="text-body-secondary">24</span></div>
                                <div class="progress"><div class="progress-bar bg-brown" style="width: 48%"></div></div>
                            </div>
                            <div>
                                <div class="d-flex justify-content-between small mb-2"><span class="fw-semibold">Facial</span><span class="text-body-secondary">18</span></div>
                                <div class="progress"><div class="progress-bar bg-brown" style="width: 36%"></div></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="view d-none" id="view-appointments">
            <div class="mb-4">
                <h1 class="h3 mb-1">Appointments</h1>
                <p class="text-body-secondary mb-0">Newest first. Click an appointment to edit it or change its status.</p>
            </div>

            <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
                <div class="card-body p-4 pb-3">
                    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-3">
                        <h2 class="h5 mb-0">All Appointments</h2>
                        <button type="button" id="btnNewAppt" class="btn btn-primary rounded-pill px-4 d-inline-flex align-items-center gap-2 fw-semibold">
                            <i class="bi bi-plus-lg"></i> Create Appointment
                        </button>
                    </div>
                    <div class="d-flex flex-wrap gap-2" id="apptFilters">
                        <button type="button" class="btn btn-sm btn-outline-primary rounded-pill px-3 fw-semibold active" data-filter="all">All <span class="count ms-1 opacity-75"></span></button>
                <button type="button" class="btn btn-sm btn-outline-primary rounded-pill px-3 fw-semibold" data-filter="pending">Pending <span class="count ms-1 opacity-75"></span></button>
                <button type="button" class="btn btn-sm btn-outline-primary rounded-pill px-3 fw-semibold" data-filter="confirmed">Confirmed <span class="count ms-1 opacity-75"></span></button>
                <button type="button" class="btn btn-sm btn-outline-primary rounded-pill px-3 fw-semibold" data-filter="completed">Completed <span class="count ms-1 opacity-75"></span></button>
                <button type="button" class="btn btn-sm btn-outline-primary rounded-pill px-3 fw-semibold" data-filter="cancelled">Cancelled <span class="count ms-1 opacity-75"></span></button>
                    </div>
                </div>
                <div class="list-group list-group-flush border-top" id="apptList"></div>
                <div id="apptEmpty" class="text-center text-body-secondary py-5 d-none">No appointments here yet.</div>
            </div>
        </section>

        <div class="modal fade" id="apptModal" tabindex="-1" aria-labelledby="apptModalTitle" aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
                <div class="modal-content border-0 rounded-4">
                    <div class="modal-header border-0 px-4 pt-4 pb-0">
                        <h2 class="modal-title h5" id="apptModalTitle">Create appointment</h2>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form id="apptForm">
                        <div class="modal-body px-4 py-3">
                            <input type="hidden" id="f-id">
                            <div class="row g-3">
                                <div class="col-12 col-md-6">
                                    <label class="form-label small fw-semibold" for="f-client">Client name</label>
                                    <input type="text" class="form-control" id="f-client" required>
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="form-label small fw-semibold" for="f-phone">Phone</label>
                                    <input type="tel" class="form-control" id="f-phone">
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="form-label small fw-semibold" for="f-service">Service</label>
                                    <select class="form-select" id="f-service" required>
                                        <option>Haircut and styling</option>
                                        <option>Hair color</option>
                                        <option>Hair treatment</option>
                                        <option>Facial</option>
                                        <option>Massage</option>
                                        <option>Manicure and pedicure</option>
                                    </select>
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="form-label small fw-semibold" for="f-stylist">Stylist / therapist</label>
                                    <input type="text" class="form-control" id="f-stylist">
                                </div>
                                <div class="col-6 col-md-3">
                                    <label class="form-label small fw-semibold" for="f-date">Date</label>
                                    <input type="date" class="form-control" id="f-date" required>
                                </div>
                                <div class="col-6 col-md-3">
                                    <label class="form-label small fw-semibold" for="f-time">Time</label>
                                    <input type="time" class="form-control" id="f-time" required>
                                </div>
                                <div class="col-6 col-md-3">
                                    <label class="form-label small fw-semibold" for="f-status">Status</label>
                                    <select class="form-select" id="f-status">
                                        <option value="pending">Pending</option>
                                        <option value="confirmed">Confirmed</option>
                                        <option value="completed">Completed</option>
                                        <option value="cancelled">Cancelled</option>
                                    </select>
                                </div>
                                <div class="col-6 col-md-3">
                                    <label class="form-label small fw-semibold" for="f-price">Price (&#8369;)</label>
                                    <input type="number" class="form-control" id="f-price" min="0" step="1">
                                </div>
                                <div class="col-12">
                                    <label class="form-label small fw-semibold" for="f-notes">Notes</label>
                                    <textarea class="form-control" id="f-notes" rows="3" placeholder="Allergies, preferences, requests..."></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer border-0 justify-content-between px-4 pb-4">
                            <button type="button" id="btnDeleteAppt" class="btn btn-link link-danger text-decoration-none px-0 d-none">
                                <i class="bi bi-trash me-1"></i>Delete
                            </button>
                            <div class="ms-auto d-flex gap-2">
                                <button type="button" class="btn btn-light rounded-pill px-4" data-bs-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary rounded-pill px-4">Save</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-sm">
                <div class="modal-content border-0 rounded-4 text-center">
                    <div class="modal-body p-4">
                        <div class="d-inline-flex rounded-circle bg-danger-subtle text-danger p-3 mb-3">
                            <i class="bi bi-trash fs-3"></i>
                        </div>
                        <h2 class="h5" id="deleteModalTitle">Delete appointment?</h2>
                        <p class="text-body-secondary mb-4">
                            This will permanently remove <strong id="deleteTarget"></strong>. This can't be undone.
                        </p>
                        <div class="d-flex gap-2 justify-content-center">
                            <button type="button" class="btn btn-light rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                            <button type="button" id="btnConfirmDelete" class="btn btn-danger rounded-pill px-4">Delete</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <section class="view d-none" id="view-clients">
            <div class="mb-4">
                <h1 class="h3 mb-1">Clients</h1>
                <p class="text-body-secondary mb-0">View client's information.</p>
            </div>
        </section>
        <section class="view d-none" id="view-services">
            <div class="mb-4">
                <h1 class="h3 mb-1">Services</h1>
                <p class="text-body-secondary mb-0">Edit available services.</p>
            </div>
        </section>
        <section class="view d-none" id="view-team">
            <div class="mb-4">
                <h1 class="h3 mb-1">Team</h1>
                <p class="text-body-secondary mb-0">Here's the list of staff. Click a staff member to edit it or view its details.</p>
            </div>

            <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
                <div class="card-body p-4 pb-3">
                    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-3">
                        <h2 class="h5 mb-0">All The Staff</h2>
                        <button type="button" id="btnNewEmp" class="btn btn-primary rounded-pill px-4 d-inline-flex align-items-center gap-2 fw-semibold">
                            <i class="bi bi-plus-lg"></i> Add Staff
                        </button>
                    </div>

                    <div class="d-flex flex-wrap gap-2" id="empFilters">
                        <button type="button" class="btn btn-sm btn-outline-primary rounded-pill px-3 fw-semibold active" data-filter="All">All <span class="count ms-1 opacity-75"></span></button>
                        <button type="button" class="btn btn-sm btn-outline-primary rounded-pill px-3 fw-semibold" data-filter="Employed">Employed <span class="count ms-1 opacity-75"></span></button>
                        <button type="button" class="btn btn-sm btn-outline-primary rounded-pill px-3 fw-semibold" data-filter="Resigned">Resigned <span class="count ms-1 opacity-75"></span></button>
                        <button type="button" class="btn btn-sm btn-outline-primary rounded-pill px-3 fw-semibold" data-filter="Terminated">Terminated <span class="count ms-1 opacity-75"></span></button>
                        <button type="button" class="btn btn-sm btn-outline-primary rounded-pill px-3 fw-semibold" data-filter="Retired">Retired <span class="count ms-1 opacity-75"></span></button>
                    </div>
                </div>
                <div class="list-group list-group-flush border-top" id="empList"></div>
                <div id="empEmpty" class="text-center text-body-secondary py-5 d-none">No Staff here yet.</div>
            </div>
        </section>

        <div class="modal fade" id="empModal" tabindex="-1" aria-labelledby="empModalTitle" aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
                <div class="modal-content border-0 rounded-4">
                    <div class="modal-header border-0 px-4 pt-4 pb-0">
                        <h2 class="modal-title h5" id="empModalTitle">Add Staff</h2>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form id="empForm">
                        <div class="modal-body px-4 py-3">
                            <input type="hidden" id="emp-id">
                            <div class="row g-3">
                                <div class="col-12 col-md-6">
                                    <label class="form-label small fw-semibold" for="emp-Employees">Staff name</label>
                                    <input type="text" class="form-control" id="emp-Employees" required>
                                </div>
                                <div class="col-6 col-md-3">
                                    <label class="form-label small fw-semibold" for="emp-date">Date of Employment</label>
                                    <input type="date" class="form-control" id="emp-date" required>
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="form-label small fw-semibold" for="emp-status">Status</label>
                                    <select class="form-select" id="emp-status">
                                        <option value="Employed">Employed</option>
                                        <option value="Resigned">Resigned</option>
                                        <option value="Terminated">Terminated</option>
                                        <option value="Retired">Retired</option>
                                    </select>
                                </div>
                                <div class="col-12">
                                    <label class="form-label small fw-semibold" for="emp-notes">Notes</label>
                                    <textarea class="form-control" id="emp-notes" rows="4"></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer border-0 justify-content-between px-4 pb-4">
                            <button type="button" id="btnDeleteEmp" class="btn btn-link link-danger text-decoration-none px-0 d-none">
                                <i class="bi bi-trash me-1"></i>Delete
                            </button>
                            <div class="ms-auto d-flex gap-2">
                                <button type="button" class="btn btn-light rounded-pill px-4" data-bs-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary rounded-pill px-4">Save</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <section class="view d-none" id="view-reports">
            <div class="mb-4">
                <h1 class="h3 mb-1">Reports</h1>
                <p class="text-body-secondary mb-0">Historical reports of sales.</p>
            </div>

            <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
                <div class="card-body p-4 pb-3">
                    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-3">
                        <h2 class="h5 mb-0">All The Sales</h2>
                        <button type="button" id="btnNewSale" class="btn btn-primary rounded-pill px-4 d-inline-flex align-items-center gap-2 fw-semibold">
                            <i class="bi bi-plus-lg"></i> Add Sale
                        </button>
                    </div>

                    <div class="d-flex flex-wrap gap-2" id="saleFilters">
                        <button type="button" class="btn btn-sm btn-outline-primary rounded-pill px-3 fw-semibold active" data-filter="ALL">All <span class="count ms-1 opacity-75"></span></button>
                        <button type="button" class="btn btn-sm btn-outline-primary rounded-pill px-3 fw-semibold" data-filter="Haircut and styling">Haircut &amp; Styling <span class="count ms-1 opacity-75"></span></button>
                        <button type="button" class="btn btn-sm btn-outline-primary rounded-pill px-3 fw-semibold" data-filter="Massage">Massage <span class="count ms-1 opacity-75"></span></button>
                        <button type="button" class="btn btn-sm btn-outline-primary rounded-pill px-3 fw-semibold" data-filter="Hair color">Hair Color <span class="count ms-1 opacity-75"></span></button>
                        <button type="button" class="btn btn-sm btn-outline-primary rounded-pill px-3 fw-semibold" data-filter="Facial">Facial <span class="count ms-1 opacity-75"></span></button>
                    </div>
                </div>
                <div class="list-group list-group-flush border-top" id="saleList"></div>
                <div id="saleEmpty" class="text-center text-body-secondary py-5 d-none">No Sales here yet.</div>
            </div>
        </section>

        <div class="modal fade" id="saleModal" tabindex="-1" aria-labelledby="saleModalTitle" aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
                <div class="modal-content border-0 rounded-4">
                    <div class="modal-header border-0 px-4 pt-4 pb-0">
                        <h2 class="modal-title h5" id="saleModalTitle">Add Sale</h2>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form id="saleForm">
                        <div class="modal-body px-4 py-3">
                            <input type="hidden" id="sale-id">
                            <div class="row g-3">
                                <div class="col-12 col-md-6">
                                    <label class="form-label small fw-semibold" for="sale-customer">Customer Name</label>
                                    <input type="text" class="form-control" id="sale-customer" required>
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="form-label small fw-semibold" for="sale-phone">Phone</label>
                                    <input type="tel" class="form-control" id="sale-phone">
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="form-label small fw-semibold" for="sale-service">Service</label>
                                    <select class="form-select" id="sale-service">
                                        <option value="Haircut and styling">Haircut &amp; Styling</option>
                                        <option value="Massage">Massage</option>
                                        <option value="Hair color">Hair Color</option>
                                        <option value="Facial">Facial</option>
                                        <option value="Manicure and pedicure">Manicure &amp; Pedicure</option>
                                        <option value="Hair treatment">Hair Treatment</option>
                                    </select>
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="form-label small fw-semibold" for="sale-stylist">Stylist / therapist</label>
                                    <input type="text" class="form-control" id="sale-stylist">
                                </div>
                                <div class="col-6 col-md-3">
                                    <label class="form-label small fw-semibold" for="sale-date">Date of Sale</label>
                                    <input type="date" class="form-control" id="sale-date" required>
                                </div>
                                <div class="col-6 col-md-3">
                                    <label class="form-label small fw-semibold" for="sale-time">Time</label>
                                    <input type="time" class="form-control" id="sale-time">
                                </div>
                                <div class="col-6 col-md-3">
                                    <label class="form-label small fw-semibold" for="sale-price">Price (&#8369;)</label>
                                    <input type="number" class="form-control" id="sale-price" min="0" step="1">
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="form-label small fw-semibold" for="sale-status">Status</label>
                                    <select class="form-select" id="sale-status">
                                        <option value="completed">Completed</option>
                                        <option value="cancelled">Cancelled</option>
                                    </select>
                                </div>
                                <div class="col-12">
                                    <label class="form-label small fw-semibold" for="sale-notes">Notes</label>
                                    <textarea class="form-control" id="sale-notes" rows="4"></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer border-0 justify-content-between px-4 pb-4">
                            <button type="button" id="btnDeleteSale" class="btn btn-link link-danger text-decoration-none px-0 d-none">
                                <i class="bi bi-trash me-1"></i>Delete
                            </button>
                            <div class="ms-auto d-flex gap-2">
                                <button type="button" class="btn btn-light rounded-pill px-4" data-bs-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary rounded-pill px-4">Save</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </main>

    <script>
        $(function () {
            var days = ['SUNDAY','MONDAY','TUESDAY','WEDNESDAY','THURSDAY','FRIDAY','SATURDAY'];
            var months = ['JANUARY','FEBRUARY','MARCH','APRIL','MAY','JUNE','JULY','AUGUST','SEPTEMBER','OCTOBER','NOVEMBER','DECEMBER'];
            var now = new Date();
            var formatted = days[now.getDay()] + ' · ' + now.getDate() + ' ' + months[now.getMonth()] + ' ' + now.getFullYear();
            $('#dateLabel').text(formatted);
        });

        $('#offcanvasNavbar .nav-link').on('click', function () {
            $('#offcanvasNavbar .nav-link').removeClass('active');
            $(this).addClass('active');

            var sectionId = '#' + this.id.replace('link-', 'view-');
            $('.view').addClass('d-none');
            $(sectionId).removeClass('d-none');

            if (window.matchMedia('(max-width: 991.98px)').matches) {
                bootstrap.Offcanvas
                    .getOrCreateInstance(document.getElementById('offcanvasNavbar'))
                    .hide();
            }
        });

        $('#view-all').on('click', function (e) {
            e.preventDefault();
            $('#link-appointments').trigger('click');
        });

        /*-----------Appointments Sample Data---------------*/
        (function () {
            var STATUS = {
                pending:   { label: 'Pending',   bar: 'bg-warning', badge: 'bg-warning-subtle text-warning-emphasis' },
                confirmed: { label: 'Confirmed', bar: 'bg-success', badge: 'bg-success-subtle text-success-emphasis' },
                completed: { label: 'Completed', bar: 'bg-info',    badge: 'bg-info-subtle text-info-emphasis' },
                cancelled: { label: 'Cancelled', bar: 'bg-danger',  badge: 'bg-danger-subtle text-danger-emphasis' }
            };

            function iso(d) {
                return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
            }
            function day(n) { var d = new Date(); d.setDate(d.getDate() + n); return iso(d); }
            function esc(s) {
                return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
                    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
                });
            }
            function fmtTime(t) {
                return new Date('1970-01-01T' + t).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
            }
            function fmtDate(d) {
                return new Date(d + 'T00:00').toLocaleDateString([], { month: 'short', day: 'numeric' });
            }

            // SAMPLE DATA
            var list = [
                { id: 1, client: 'Maria Santos',   phone: '0917 000 0001', service: 'Hair color',            stylist: 'Liny',  date: day(0), time: '10:00', status: 'confirmed', price: 1800, notes: 'Wants ash brown.' },
                { id: 2, client: 'Ana Reyes',      phone: '0917 000 0002', service: 'Facial',                stylist: 'Joan',  date: day(0), time: '11:30', status: 'pending',   price: 600,  notes: 'Sensitive skin.' },
                { id: 3, client: 'Joy Dela Cruz',  phone: '0917 000 0003', service: 'Massage',               stylist: 'Rina',  date: day(0), time: '13:00', status: 'confirmed', price: 700,  notes: '' },
                { id: 4, client: 'Liza Mendoza',   phone: '0917 000 0004', service: 'Haircut and styling',   stylist: 'Liny',  date: day(0), time: '15:00', status: 'pending',   price: 350,  notes: '' },
                { id: 5, client: 'Carla Bautista', phone: '0917 000 0005', service: 'Manicure and pedicure', stylist: 'Joan',  date: day(1), time: '09:30', status: 'confirmed', price: 450,  notes: 'Gel polish.' },
                { id: 6, client: 'Nena Villanueva',phone: '0917 000 0006', service: 'Hair treatment',        stylist: 'Liny',  date: day(1), time: '14:00', status: 'pending',   price: 1500, notes: 'Rebond.' },
                { id: 7, client: 'Rosa Garcia',    phone: '0917 000 0007', service: 'Massage',               stylist: 'Rina',  date: day(-1),time: '16:00', status: 'completed', price: 700,  notes: '' },
                { id: 8, client: 'Tess Navarro',   phone: '0917 000 0008', service: 'Facial',                stylist: 'Joan',  date: day(-1),time: '10:30', status: 'cancelled', price: 600,  notes: 'Client cancelled by message.' }
            ];
            var nextId = 100, newId = null, filter = 'all';

            var listEl = document.getElementById('apptList');
            var emptyEl = document.getElementById('apptEmpty');
            var modalEl = document.getElementById('apptModal');
            var modal = bootstrap.Modal.getOrCreateInstance(modalEl);
            var form = document.getElementById('apptForm');
            var $ = function (id) { return document.getElementById(id); };

            /* Add New Appointment*/
            function render() {
                var shown = list.filter(function (a) { return filter === 'all' || a.status === filter; })
                    .sort(function (a, b) { return b.id - a.id; });

                listEl.innerHTML = shown.map(function (a) {
                    var s = STATUS[a.status];
                    var off = a.status === 'cancelled';
                    return '<div class="list-group-item list-group-item-action d-flex align-items-center gap-3 px-4 py-3" data-id="' + a.id + '" role="button" tabindex="0">' +
                        '<span class="time-pill' + (off ? ' opacity-50' : '') + '">' + fmtTime(a.time) + '</span>' +
                        '<div class="flex-grow-1"><div class="fw-semibold' + (off ? ' text-decoration-line-through text-body-secondary' : '') + '">' + esc(a.client) +
                        (a.id === newId ? ' <span class="badge text-bg-primary ms-1">New</span>' : '') + '</div>' +
                        '<small class="text-body-secondary">' + esc(a.service) + (a.stylist ? ' &middot; ' + esc(a.stylist) : '') + '</small></div>' +
                        '<div class="text-end"><span class="badge rounded-pill ' + s.badge + '">' + s.label + '</span>' +
                        '<div class="small text-body-secondary mt-1">' + fmtDate(a.date) + '</div></div></div>';
                }).join('');

                emptyEl.classList.toggle('d-none', shown.length > 0);

                document.querySelectorAll('#apptFilters [data-filter]').forEach(function (chip) {
                    var f = chip.dataset.filter;
                    chip.classList.toggle('active', f === filter);
                    chip.querySelector('.count').textContent = f === 'all' ? list.length :
                        list.filter(function (a) { return a.status === f; }).length;
                });
            }

            /* Add or Edit modal if else */
            function openModal(a) {
                form.reset();
                $('apptModalTitle').textContent = a ? 'Edit appointment' : 'Create appointment';
                $('btnDeleteAppt').classList.toggle('d-none', !a);
                $('f-id').value     = a ? a.id : '';
                $('f-client').value = a ? a.client : '';
                $('f-phone').value  = a ? a.phone : '';
                $('f-service').value= a ? a.service : 'Haircut and styling';
                $('f-stylist').value= a ? a.stylist : '';
                $('f-date').value   = a ? a.date : day(0);
                $('f-time').value   = a ? a.time : '';
                $('f-status').value = a ? a.status : 'pending';
                $('f-price').value  = a ? a.price : '';
                $('f-notes').value  = a ? a.notes : '';
                modal.show();
            }

            function findById(id) { return list.filter(function (a) { return String(a.id) === String(id); })[0]; }

            $('btnNewAppt').addEventListener('click', function () { openModal(null); });

            function openFromCard(e) {
                var card = e.target.closest('[data-id]');
                if (card) openModal(findById(card.dataset.id));
            }
            listEl.addEventListener('click', openFromCard);
            listEl.addEventListener('keydown', function (e) { if (e.key === 'Enter') openFromCard(e); });

            document.getElementById('apptFilters').addEventListener('click', function (e) {
                var chip = e.target.closest('[data-filter]');
                if (chip) { filter = chip.dataset.filter; render(); }
            });

            form.addEventListener('submit', function (e) {
                e.preventDefault();
                var data = {
                    client: $('f-client').value.trim(), phone: $('f-phone').value.trim(),
                    service: $('f-service').value, stylist: $('f-stylist').value.trim(),
                    date: $('f-date').value, time: $('f-time').value, status: $('f-status').value,
                    price: Number($('f-price').value) || 0, notes: $('f-notes').value.trim()
                };
                var id = $('f-id').value;
                if (id) { Object.assign(findById(id), data); }
                else { data.id = nextId++; newId = data.id; list.push(data); }
                modal.hide();
                render();
            });

            var confirmEl = document.getElementById('deleteModal');
            var confirmModal = bootstrap.Modal.getOrCreateInstance(confirmEl);
            var pendingDeleteId = null;

            /* Delete modal */
            $('btnDeleteAppt').addEventListener('click', function () {
                pendingDeleteId = $('f-id').value;
                var a = findById(pendingDeleteId);
                $('deleteTarget').textContent = a ? a.client + ' (' + fmtDate(a.date) + ', ' + fmtTime(a.time) + ')' : 'this appointment';
                modal.hide();
                modalEl.addEventListener('hidden.bs.modal', function () { confirmModal.show(); }, { once: true });
            });

            $('btnConfirmDelete').addEventListener('click', function () {
                list = list.filter(function (a) { return String(a.id) !== pendingDeleteId; });
                pendingDeleteId = null;
                confirmModal.hide();
                render();
            });

            confirmEl.addEventListener('hidden.bs.modal', function () {
                if (pendingDeleteId !== null) modal.show();
            });

            render();
        })();  
    </script>

    <script>
        /*-----------Employee Team Data---------------*/
        (function () {
            var STATUS = {
                Owner: { label: 'Owner', badge: 'bg-warning-subtle text-warning-emphasis' },
                Employed: { label: 'Employed', badge: 'bg-success-subtle text-success-emphasis' },
                Resigned: { label: 'Resigned', badge: 'bg-info-subtle text-info-emphasis' },
                Terminated: { label: 'Terminated', badge: 'bg-danger-subtle text-danger-emphasis' },
                Retired: { label: 'Retired', badge: 'bg-secondary-subtle text-secondary-emphasis' }
            };

            function esc(s) {
                return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
                    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
                });
            }
            function fmtDate(d) {
                return d ? new Date(d + 'T00:00').toLocaleDateString([], { month: 'short', day: 'numeric' }) : '—';
            }
            // SAMPLE DATA
            var list = [
                { id: 1, Employees: 'Liny', status: 'Owner', date: '2023-01-01', notes: 'Owner of the business' },
                { id: 2, Employees: 'Joan', status: 'Employed', date: '2023-01-02', notes: '' },
                { id: 3, Employees: 'Rina', status: 'Employed', date: '2023-01-03', notes: '' },
                { id: 4, Employees: 'Emma', status: 'Employed', date: '2023-01-04', notes: '' },
                { id: 5, Employees: 'Sarah', status: 'Retired', date: '2023-01-05', notes: '' },
                { id: 6, Employees: 'Nina', status: 'Employed', date: '2023-01-05', notes: '' },
                { id: 7, Employees: 'Grace', status: 'Terminated', date: '2024-01-07', notes: 'Terminated on 2024-01-07.' },
                { id: 8, Employees: 'Cindy', status: 'Employed', date: '2023-01-07', notes: '' },
                { id: 9, Employees: 'Linda', status: 'Resigned', date: '2023-01-08', notes: 'Resigned on 2026-02-08.' }
            ];
            var nextId = 100, newId = null, filter = 'All';

            var listEl = document.getElementById('empList');
            var emptyEl = document.getElementById('empEmpty');
            var modalEl = document.getElementById('empModal');
            var modal = bootstrap.Modal.getOrCreateInstance(modalEl);
            var form = document.getElementById('empForm');
            var $ = function (id) { return document.getElementById(id); };

            function render() {
                var shown = list.filter(function (e) { return filter === 'All' || e.status === filter; })
                    .sort(function (a, b) { return b.id - a.id; });

                listEl.innerHTML = shown.map(function (e) {
                    var s = STATUS[e.status] || STATUS.Employed;
                    var off = e.status === 'Terminated' || e.status === 'Retired' || e.status === 'Resigned';
                    var noteText = e.notes ? esc(e.notes) : 'No notes';
                    return '<div class="list-group-item list-group-item-action d-flex align-items-center gap-3 px-4 py-3" data-id="' + e.id + '" role="button" tabindex="0">' +
                        '<span class="time-pill' + (off ? ' opacity-50' : '') + '">' + fmtDate(e.date) + '</span>' +
                        '<div class="flex-grow-1"><div class="fw-semibold' + (off ? ' text-decoration-line-through text-body-secondary' : '') + '">' + esc(e.Employees) +
                        (e.id === newId ? ' <span class="badge text-bg-primary ms-1">New</span>' : '') + '</div>' +
                        '<small class="text-body-secondary">' + noteText + '</small></div>' +
                        '<div class="Huge text-end"><span class="badge rounded-pill ' + s.badge + '">' + s.label + '</span>' +
                        '</div></div>';
                }).join('');

                emptyEl.classList.toggle('d-none', shown.length > 0);

                document.querySelectorAll('#empFilters [data-filter]').forEach(function (chip) {
                    var f = chip.dataset.filter;
                    chip.classList.toggle('active', f === filter);
                    chip.querySelector('.count').textContent = f === 'All' ? list.length :
                        list.filter(function (e) { return e.status === f; }).length;
                });
            }
            // Add or Edit modal if else
            function openModal(e) {
                form.reset();
                $('empModalTitle').textContent = e ? 'Edit Staff' : 'Add Staff';
                $('btnDeleteEmp').classList.toggle('d-none', !e);
                $('emp-id').value = e ? e.id : '';
                $('emp-Employees').value = e ? e.Employees : '';
                $('emp-status').value = e ? e.status : 'Employed';
                $('emp-date').value = e ? e.date : '';
                $('emp-notes').value = e ? e.notes : '';
                modal.show();
            }

            function findById(id) {
                return list.find(function (e) { return String(e.id) === String(id); }) || null;
            }

            $('btnNewEmp').addEventListener('click', function () { openModal(null); });

            function openFromCard(event) {
                var card = event.target.closest('[data-id]');
                if (card) openModal(findById(card.dataset.id));
            }
            listEl.addEventListener('click', openFromCard);
            listEl.addEventListener('keydown', function (e) { if (e.key === 'Enter') openFromCard(e); });

            document.getElementById('empFilters').addEventListener('click', function (e) {
                var chip = e.target.closest('[data-filter]');
                if (chip) { filter = chip.dataset.filter; render(); }
            });

            form.addEventListener('submit', function (e) {
                e.preventDefault();
                var data = {
                    Employees: $('emp-Employees').value.trim(),
                    status: $('emp-status').value,
                    notes: $('emp-notes').value.trim()
                };
                var id = $('emp-id').value;
                if (id) { Object.assign(findById(id), data); }
                else { data.id = nextId++; newId = data.id; list.push(data); }
                modal.hide();
                render();
            });

            var confirmEl = document.getElementById('deleteModal');
            var confirmModal = bootstrap.Modal.getOrCreateInstance(confirmEl);
            var pendingDeleteId = null;
            // Delete modal
            $('btnDeleteEmp').addEventListener('click', function () {
                pendingDeleteId = $('emp-id').value;
                var e = findById(pendingDeleteId);
                $('deleteTarget').textContent = e ? e.Employees : 'this employee';
                modal.hide();
                modalEl.addEventListener('hidden.bs.modal', function () { confirmModal.show(); }, { once: true });
            });

            $('btnConfirmDelete').addEventListener('click', function () {
                list = list.filter(function (e) { return String(e.id) !== pendingDeleteId; });
                pendingDeleteId = null;
                confirmModal.hide();
                render();
            });

            confirmEl.addEventListener('hidden.bs.modal', function () {
                if (pendingDeleteId !== null) modal.show();
            });

            render();
        })();
    </script>

    <script>
         /*-----------Sales Sample Data---------------*/
        (function () {
            var STATUS = {
                completed: { label: 'Completed', bar: 'bg-info', badge: 'bg-info-subtle text-info-emphasis' },
                cancelled: { label: 'Cancelled', bar: 'bg-secondary', badge: 'bg-secondary-subtle text-secondary-emphasis' }
            };

            function iso(d) {
                return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
            }
            function day(n) { var d = new Date(); d.setDate(d.getDate() + n); return iso(d); }
            function esc(s) {
                return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
                    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
                });
            }
            function normalizeService(value) {
                return String(value || '').replace(/&/g, 'and').replace(/\s+/g, ' ').trim().toLowerCase();
            }
            function fmtTime(t) {
                if (!t) return '--:--';
                var dt = new Date('1970-01-01T' + t);
                return isNaN(dt.getTime()) ? '--:--' : dt.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
            }
            function fmtDate(d) {
                if (!d) return '';
                var date = new Date(d + 'T00:00');
                return isNaN(date.getTime()) ? '' : date.toLocaleDateString([], { month: 'short', day: 'numeric' });
            }

            // SAMPLE DATA
            var list = [
                { id: 1, client: 'Rosa Garcia',      phone: '0917 000 0007', service: 'Massage',               stylist: 'Rina',  date: day(-1),time: '16:00', status: 'completed', price: 700,  notes: '' },
                { id: 2, client: 'Maria Mendoza',    phone: '0917 000 0001', service: 'Hair color',            stylist: 'Liny',  date: day(0), time: '10:00', status: 'completed', price: 1800, notes: 'Wants ash brown.' },
                { id: 3, client: 'Ana Santos',       phone: '0917 000 0002', service: 'Facial',                stylist: 'Joan',  date: day(0), time: '11:30', status: 'completed', price: 600,  notes: 'Sensitive skin.' },
                { id: 4, client: 'Joy Navarro',      phone: '0917 000 0003', service: 'Massage',               stylist: 'Rina',  date: day(0), time: '13:00', status: 'completed', price: 700,  notes: '' },
                { id: 5, client: 'Liza De La Cruz',  phone: '0917 000 0004', service: 'Haircut and styling',   stylist: 'Liny',  date: day(0), time: '15:00', status: 'completed',   price: 350,  notes: '' },
                { id: 6, client: 'Carla Villanueva', phone: '0917 000 0005', service: 'Manicure and pedicure', stylist: 'Joan',  date: day(1), time: '09:30', status: 'completed', price: 450,  notes: 'Gel polish.' },
                { id: 7, client: 'Nena Padua',       phone: '0917 000 0006', service: 'Hair treatment',        stylist: 'Liny',  date: day(1), time: '14:00', status: 'completed',   price: 1500, notes: 'Rebond.' },
                { id: 8, client: 'Tess Reyes',       phone: '0917 000 0008', service: 'Facial',                stylist: 'Joan',  date: day(-1),time: '10:30', status: 'completed', price: 600,  notes: 'Client cancelled by message.' }
            ];
            var nextId = 100, newId = null, filter = 'ALL';

            var listEl = document.getElementById('saleList');
            var emptyEl = document.getElementById('saleEmpty');
            var modalEl = document.getElementById('saleModal');
            var modal = bootstrap.Modal.getOrCreateInstance(modalEl);
            var form = document.getElementById('saleForm');
            var $ = function (id) { return document.getElementById(id); };

            /* Add New Sale */
            function render() {
                var shown = list.filter(function (a) {
                    return filter === 'ALL' || normalizeService(a.service) === normalizeService(filter);
                }).sort(function (a, b) { return b.id - a.id; });

                listEl.innerHTML = shown.map(function (a) {
                    var s = STATUS[a.status] || STATUS.completed;
                    var off = a.status === 'cancelled';
                    return '<div class="list-group-item list-group-item-action d-flex align-items-center gap-3 px-4 py-3" data-id="' + a.id + '" role="button" tabindex="0">' +
                        '<span class="time-pill' + (off ? ' opacity-50' : '') + '">' + fmtDate(a.date) + ', ' + fmtTime(a.time) + '</span>' +
                        '<div class="flex-grow-1"><div class="fw-semibold' + (off ? ' text-decoration-line-through text-body-secondary' : '') + '">' + esc(a.client) +
                        (a.id === newId ? ' <span class="badge text-bg-primary ms-1">New</span>' : '') + '</div>' +
                        '<small class="text-body-secondary">' + esc(a.service) + (a.stylist ? ' &middot; ' + esc(a.stylist) : '') + '</small></div>' +
                        '<div class="medium text-end"><span class="badge rounded-pill ' + s.badge + '">' + s.label + '</span>' +
                        '<div class="medium text-body-secondary mt-1">' + ('₱' + Number(a.price || 0).toLocaleString('en-PH')) + '</div></div></div>';
                }).join('');

                emptyEl.classList.toggle('d-none', shown.length > 0);

                document.querySelectorAll('#saleFilters [data-filter]').forEach(function (chip) {
                    var f = chip.dataset.filter;
                    var filterValue = f === 'ALL' ? 'ALL' : normalizeService(f);
                    chip.classList.toggle('active', f === 'ALL' ? filter === 'ALL' : normalizeService(filter) === filterValue);
                    chip.querySelector('.count').textContent = f === 'ALL' ? list.length :
                        list.filter(function (a) { return normalizeService(a.service) === filterValue; }).length;
                });
            }

            /* Add or Edit modal if else */
            function openModal(s) {
                form.reset();
                $('saleModalTitle').textContent = s ? 'Edit sale' : 'Create sale';
                $('btnDeleteSale').classList.toggle('d-none', !s);
                $('sale-id').value      = s ? s.id : '';
                $('sale-customer').value = s ? s.client : '';
                $('sale-phone').value   = s ? s.phone : '';
                $('sale-service').value = s ? s.service : 'Haircut and styling';
                $('sale-stylist').value = s ? s.stylist : '';
                $('sale-date').value    = s ? s.date : day(0);
                $('sale-time').value    = s ? s.time : '';
                $('sale-status').value  = s ? s.status : 'completed';
                $('sale-price').value   = s ? s.price : '';
                $('sale-notes').value   = s ? s.notes : '';
                modal.show();
            }

            function findById(id) { return list.filter(function (a) { return String(a.id) === String(id); })[0]; }

            $('btnNewSale').addEventListener('click', function () { openModal(null); });

            function openFromCard(e) {
                var card = e.target.closest('[data-id]');
                if (card) openModal(findById(card.dataset.id));
            }
            listEl.addEventListener('click', openFromCard);
            listEl.addEventListener('keydown', function (e) { if (e.key === 'Enter') openFromCard(e); });

            document.getElementById('saleFilters').addEventListener('click', function (e) {
                var chip = e.target.closest('[data-filter]');
                if (chip) { filter = chip.dataset.filter; render(); }
            });

            form.addEventListener('submit', function (e) {
                e.preventDefault();
                var data = {
                    client: $('sale-customer').value.trim(), phone: $('sale-phone').value.trim(),
                    service: $('sale-service').value, stylist: $('sale-stylist').value.trim(),
                    date: $('sale-date').value, time: $('sale-time').value, status: $('sale-status').value,
                    price: Number($('sale-price').value) || 0, notes: $('sale-notes').value.trim()
                };
                var id = $('sale-id').value;
                if (id) { Object.assign(findById(id), data); }
                else { data.id = nextId++; newId = data.id; list.push(data); }
                modal.hide();
                render();
            });

            var confirmEl = document.getElementById('deleteModal');
            var confirmModal = bootstrap.Modal.getOrCreateInstance(confirmEl);
            var pendingDeleteId = null;

            /* Delete modal */
            $('btnDeleteSale').addEventListener('click', function () {
                pendingDeleteId = $('sale-id').value;
                var s = findById(pendingDeleteId);
                $('deleteTarget').textContent = s ? s.client + ' (' + fmtDate(s.date) + ', ' + fmtTime(s.time) + ')' : 'this sale';
                modal.hide();
                modalEl.addEventListener('hidden.bs.modal', function () { confirmModal.show(); }, { once: true });
            });

            $('btnConfirmDelete').addEventListener('click', function () {
                list = list.filter(function (s) { return String(s.id) !== pendingDeleteId; });
                pendingDeleteId = null;
                confirmModal.hide();
                render();
            });

            confirmEl.addEventListener('hidden.bs.modal', function () {
                if (pendingDeleteId !== null) modal.show();
            });

            render();
        })();  
    </script>
</body>
</html>