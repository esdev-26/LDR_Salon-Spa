<?php
require_once('auth.php');

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    http_response_code(405);
    header('Allow: POST');
    echo 'Method not allowed.';
    exit;
}

$table = $_POST['table'] ?? '';
$allowedRoles = in_array($table, ['services', 'sales', 'staff'], true)
    ? ['admin', 'owner']
    : ['admin', 'owner', 'staff'];
require_authenticated_user($allowedRoles);

include('connect.php');
if ($error) { http_response_code(500); echo $error; exit; }

$tables = ['appointments', 'clients', 'services', 'staff', 'sales'];
$id     = (int)($_POST['id'] ?? 0);

if (!in_array($table, $tables, true) || $id <= 0) {
    http_response_code(400);
    echo 'Invalid request.';
    exit;
}

$stmt = $conn->prepare("DELETE FROM `$table` WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
echo $id;