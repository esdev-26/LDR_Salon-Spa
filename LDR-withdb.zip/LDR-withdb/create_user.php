
<?php
include('connect.php');

$username = 'admin';
$password = 'admin123';
$role = 'admin';
$passwordHash = password_hash($password, PASSWORD_DEFAULT);

$stmt = $conn->prepare(
    "INSERT INTO users (username, password_hash, role)
     VALUES (?, ?, ?)"
);

$stmt->bind_param("sss", $username, $passwordHash, $role);

if ($stmt->execute()) {
    echo "Account created successfully!";
} else {
    echo "Error creating account: " . $stmt->error;
}

$stmt->close();
?>
