<?php
include('connect.php');
if ($error) { http_response_code(500); echo $error; exit; }

$id    = (int)($_POST['id'] ?? 0);
$name  = trim($_POST['name'] ?? '');
$phone = trim($_POST['phone'] ?? '');
$email = trim($_POST['email'] ?? '');
$notes = trim($_POST['notes'] ?? '');

if ($name === '' || $phone === '') {
    http_response_code(400);
    echo 'Name and phone are required.';
    exit;
}

if ($id === 0) {
    $created = date('Y-m-d');                  // the server sets the date added
    $stmt = $conn->prepare(
        "INSERT INTO clients (name, phone, email, notes, created_at) VALUES (?, ?, ?, ?, ?)"
    );
    $stmt->bind_param("sssss", $name, $phone, $email, $notes, $created);
    $stmt->execute();
    echo $conn->insert_id;
} else {
    $stmt = $conn->prepare(
        "UPDATE clients SET name=?, phone=?, email=?, notes=? WHERE id=?"
    );
    $stmt->bind_param("ssssi", $name, $phone, $email, $notes, $id);
    $stmt->execute();
    echo $id;
}