<?php
include('connect.php');
if ($error) { http_response_code(500); echo $error; exit; }

$id     = (int)($_POST['id'] ?? 0);
$name   = trim($_POST['Employees'] ?? '');
$status = $_POST['status'] ?? 'Employed';
$date   = ($_POST['date'] ?? '') ?: null;      // empty date becomes NULL
$notes  = trim($_POST['notes'] ?? '');

if ($name === '') {
    http_response_code(400);
    echo 'Staff name is required.';
    exit;
}

if ($id === 0) {
    $stmt = $conn->prepare(
        "INSERT INTO staff (name, status, date_employed, notes) VALUES (?, ?, ?, ?)"
    );
    $stmt->bind_param("ssss", $name, $status, $date, $notes);
    $stmt->execute();
    echo $conn->insert_id;
} else {
    $stmt = $conn->prepare(
        "UPDATE staff SET name=?, status=?, date_employed=?, notes=? WHERE id=?"
    );
    $stmt->bind_param("ssssi", $name, $status, $date, $notes, $id);
    $stmt->execute();
    echo $id;
}