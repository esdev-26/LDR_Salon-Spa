<?php
session_start();

if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'] ?? '', ['admin', 'owner'], true)) {
    http_response_code(403);
    echo 'You are not allowed to edit reports.';
    exit;
}

include('connect.php');
if ($error) { http_response_code(500); echo $error; exit; }

$id               = (int)($_POST['id'] ?? 0);
$client           = trim($_POST['client'] ?? '');
$phone            = trim($_POST['phone'] ?? '');
$service          = trim($_POST['service'] ?? '');
$serviceCategory  = trim($_POST['service_category'] ?? '');
$stylist          = trim($_POST['stylist'] ?? '');
$date             = $_POST['date'] ?? '';
$time             = ($_POST['time'] ?? '') ?: null;
$status           = $_POST['status'] ?? '';
$price            = $_POST['price'] ?? '';
$notes            = trim($_POST['notes'] ?? '');
$validCategories = ['Haircut and Styling', 'Massage', 'Hair Color', 'Manicure and Pedicure'];

$parsedDate = DateTime::createFromFormat('!Y-m-d', $date);
$validDate = $parsedDate && $parsedDate->format('Y-m-d') === $date;
$validTime = $time === null || (bool)preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d$/', $time);

if ($id === 0) {
    if ($client !== 'Walk-in' || $status !== 'completed') {
        http_response_code(400);
        echo 'Only completed sales for a walk-in client can be added here.';
        exit;
    }

    $activeServiceStmt = $conn->prepare("SELECT category FROM services WHERE name = ? AND status = 'Active' LIMIT 1");
    $activeServiceStmt->bind_param("s", $service);
    $activeServiceStmt->execute();
    $activeService = $activeServiceStmt->get_result()->fetch_assoc();
    if (!$activeService) {
        http_response_code(400);
        echo 'Select an active service for the walk-in sale.';
        exit;
    }
    $serviceCategory = (string)$activeService['category'];
}

if ($serviceCategory === '') {
    $categoryStmt = $conn->prepare("SELECT category FROM services WHERE name = ? LIMIT 1");
    $categoryStmt->bind_param("s", $service);
    $categoryStmt->execute();
    $serviceCategory = (string)($categoryStmt->get_result()->fetch_assoc()['category'] ?? '');
}

if ($id < 0 || $client === '' || strlen($client) > 100 ||
    strlen($phone) > 30 || $service === '' || strlen($service) > 100 ||
    strlen($stylist) > 100 || !$validDate || !$validTime ||
    !in_array($status, ['completed', 'cancelled'], true) ||
    !in_array($serviceCategory, $validCategories, true) ||
    !is_numeric($price) || (float)$price < 0) {
    http_response_code(400);
    echo 'Please provide valid sale details.';
    exit;
}

try {
    if ($id === 0) {
        $stmt = $conn->prepare(
            "INSERT INTO sales (client, phone, service, service_category, stylist, sale_date, sale_time, status, price, notes)
             VALUES (?, ?, ?, ?, ?, ?, ?, 'completed', ?, ?)"
        );
        $stmt->bind_param("sssssssds", $client, $phone, $service, $serviceCategory, $stylist, $date, $time, $price, $notes);
        $stmt->execute();
        echo $conn->insert_id;
        exit;
    }

    $stmt = $conn->prepare(
        "UPDATE sales
         SET client=?, phone=?, service=?, service_category=?, stylist=?, sale_date=?, sale_time=?, status=?, price=?, notes=?
         WHERE id=?"
    );
    $stmt->bind_param("ssssssssdsi", $client, $phone, $service, $serviceCategory, $stylist, $date, $time, $status, $price, $notes, $id);
    $stmt->execute();

    if ($stmt->affected_rows === 0) {
        $check = $conn->prepare("SELECT id FROM sales WHERE id = ?");
        $check->bind_param("i", $id);
        $check->execute();
        if (!$check->get_result()->fetch_assoc()) {
            http_response_code(404);
            echo 'Sale not found.';
            exit;
        }
    }

    echo $id;
} catch (mysqli_sql_exception $e) {
    http_response_code(500);
    echo 'Could not save the sale.';
}
