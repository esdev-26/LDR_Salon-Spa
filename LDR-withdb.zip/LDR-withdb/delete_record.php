<?php
session_start();

include('connect.php');
if ($error) { http_response_code(500); echo $error; exit; }

$tables = ['appointments', 'clients', 'services', 'staff', 'sales'];   // whitelist
$table  = $_POST['table'] ?? '';
$id     = (int)($_POST['id'] ?? 0);

if (in_array($table, ['services', 'sales'], true) &&
    (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'] ?? '', ['admin', 'owner'], true))) {
    http_response_code(403);
    echo 'You are not allowed to manage this record.';
    exit;
}

if (!in_array($table, $tables, true) || $id <= 0) {
    http_response_code(400);
    echo 'Invalid request.';
    exit;
}

$stmt = $conn->prepare("DELETE FROM `$table` WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
echo $id;