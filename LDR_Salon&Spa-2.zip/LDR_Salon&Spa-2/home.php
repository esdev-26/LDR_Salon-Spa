<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liny Delos Reyes Salon & Spa</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="bootstrap-icons-1.13.1/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/custom.css">
    <link rel="icon" href="Logo/circular-logo.png" type="image/png">
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/jquery-4.0.0.min.js"></script>
</head>
<body class="d-flex flex-column min-vh-100 ">
    <header style="z-index: 9999;">
        <nav class="navbar fixed-top bg-body-tertiary border-bottom py-0 display: block">
            <div class="container-fluid px-3">
                <div class="d-flex align-items-center gap-3 me-auto">
                    <div class="brand-block d-none d-lg-block">
                        <div class="date-label" id="dateLabel"></div>
                        <a class="navbar-brand mb-0" href="#">Home</a>
                    </div>
                </div>
                <div class="d-flex nav-links-adaptive mr-50 display: block">
                    <div class="h-100 p-3 m-0 d-flex align-items-center mid-container-active">
                        <a class="navbar-brand text-uppercase fs-6 tracking-wide" href="#">Home</a>
                    </div>
                    <div class="h-100 p-3 m-0 d-flex align-items-center mid-container">
                        <a class="navbar-brand text-uppercase fs-6 tracking-wide" href="#">About</a>
                    </div>
                    <div class="h-100 p-3 m-0 d-flex align-items-center mid-container">
                        <a class="navbar-brand text-uppercase fs-6 tracking-wide" href="#">Services</a>
                    </div>
                    <div class="h-100 p-3 m-0 d-flex align-items-center mid-container">
                        <a class="navbar-brand text-uppercase fs-6 tracking-wide" href="#">FAQS</a>
                    </div>
                </div>
                <div class="d-flex align-items-center gap-3 mr-auto display: block mid-container rounded-pill">
                    <a href="#" class="btn border btn-lg px-4 py-2 rounded-pill shadow-sm d-inline-flex align-items-center gap-2 fw-semibold text-uppercase fs-6">
                    <i class="bi bi-box-arrow-in-right"></i>
                       Log In
                    </a>
                </div>
            </div>
        </nav>
    </header>

    
    <main class="flex-grow-1">
        <div id="carouselExampleAutoplaying" class="carousel slide carousel-dark" data-bs-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="Logo/nobg-logo.png" class="d-block w-100" alt="Logo" style="height: 650px;">
                </div>
                <div class="carousel-item">
                    <img src="Logo/nobg-logo.png" class="d-block w-100" alt="Logo" style="height: 650px;">
                </div>
                <div class="carousel-item">
                    <img src="Logo/nobg-logo.png" class="d-block w-100" alt="Logo" style="height: 650px;">
                </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
        <hr/>
        <section id="about" class="py-5 bg-body">
            <h2 class="text-center mb-4 text-decoration-underline">About</h2>
            <div class="container">
                <div class="row align-items-center g-5">

                    <div class="col-12 col-lg-5">
                        <div class="about-photo-wrap position-relative mx-3 mx-lg-0">
                            <img src="Logo/nobg-logo.png"
                                alt="Inside Liny Delos Reyes Salon & Spa"
                                class="img-fluid w-100 rounded-4 shadow object-fit-cover bg-white p-4"
                                style="aspect-ratio: 4 / 5;">
                        </div>
                    </div>

                    <div class="col-12 col-lg-7">
                        <h2 class="display-6 fw-semibold mb-3">A neighborhood salon where you can slow down</h2>

                        <p class="lead text-body-secondary mb-3">
                            Liny Delos Reyes Salon &amp; Spa has been caring for hair, skin, and tired shoulders in Caloocan City.
                        </p>
                        <p class="text-body-secondary mb-4">
                            We keep things simple: skilled hands, good products, and time for every client.
                            Whether you drop by for a quick trim or book a whole afternoon, we'll listen first
                            and then take care of the rest.
                        </p>

                        <ul class="list-unstyled row row-cols-1 row-cols-sm-2 g-3 mb-4">
                            <li class="col d-flex align-items-start gap-3">
                                <i class="bi bi-scissors fs-4 about-accent" aria-hidden="true"></i>
                                <div>
                                    <div class="fw-semibold">Trained stylists</div>
                                    <small class="text-body-secondary">Cuts and color made for you.</small>
                                </div>
                            </li>
                            <li class="col d-flex align-items-start gap-3">
                                <i class="bi bi-flower2 fs-4 about-accent" aria-hidden="true"></i>
                                <div>
                                    <div class="fw-semibold">Relaxing spa treatments</div>
                                    <small class="text-body-secondary">Massage and facials that reset your day.</small>
                                </div>
                            </li>
                            <li class="col d-flex align-items-start gap-3">
                                <i class="bi bi-patch-check fs-4 about-accent" aria-hidden="true"></i>
                                <div>
                                    <div class="fw-semibold">Quality products</div>
                                    <small class="text-body-secondary">Gentle on your hair and skin.</small>
                                </div>
                            </li>
                            <li class="col d-flex align-items-start gap-3">
                                <i class="bi bi-people fs-4 about-accent" aria-hidden="true"></i>
                                <div>
                                    <div class="fw-semibold">Walk-ins welcome</div>
                                    <small class="text-body-secondary">Or book ahead to save your slot.</small>
                                </div>
                            </li>
                        </ul>

                        <div class="d-flex flex-wrap align-items-center gap-3">
                            <a href="https://maps.app.goo.gl/UTCrQZbCdqxAWLkZ6" class="btn btn-dark rounded-pill px-4" target="_blank" rel="noopener noreferrer">Visit Us!</a>
                        </div>
                    </div>

                </div>
            </div>
        </section>
        <hr/>
        <section class="">
            <div class="container">
                <h2 class="text-center mb-4 text-decoration-underline">Services</h2>

                <div class="row g-4">
                    <div class="col-12 col-md-6 col-lg-4">
                        <div class="card h-100">
                            <img src="Logo/circular-logo.png"
                                class="card-img-top mx-auto d-block my-3"
                                alt="Logo"
                                style="height: 150px; width: 150px;">
                            <div class="card-body bg-custom-brown text-white rounded d-flex flex-column justify-content-center">
                                <h5 class="card-title">Card title</h5>
                                <p class="card-text">Some quick example text to build on the card title.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-4">
                        <div class="card p-3 text-center h-100">
                            <img src="Logo/circular-logo.png"
                                class="card-img-top mx-auto d-block"
                                alt="Logo"
                                style="height: 150px; width: 150px;">
                            <div class="card-body">
                                <h5 class="card-title">Card title</h5>
                                <p class="card-text">Some quick example text to build on the card title.</p>
                                <a href="#" class="btn btn-primary">Go somewhere</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-4">
                        <div class="card p-3 text-center h-100">
                            <img src="Logo/circular-logo.png"
                                class="card-img-top mx-auto d-block"
                                alt="Logo"
                                style="height: 150px; width: 150px;">
                            <div class="card-body">
                                <h5 class="card-title">Card title</h5>
                                <p class="card-text">Some quick example text to build on the card title.</p>
                                <a href="#" class="btn btn-primary">Go somewhere</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <hr/>
        <section id="faqs" class="py-5 bg-body">
            <h2 class="text-center mb-4 text-decoration-underline">FAQS</h2>
            <div class="container">
                <div class="row g-5">
                    <div class="col-12 col-lg-4">
                        <div class="position-lg-sticky" style="top: 6rem;">
                            <h2 class="display-6 fw-semibold mb-3">Questions, answered</h2>
                            <p class="text-body-secondary mb-4">
                                Booking, payments, and what to expect at your visit. Can't find what you need? Just ask us.
                            </p>
                            <div class="faq-help p-4">
                                <div class="d-flex align-items-center gap-3 mb-3">
                                    <i class="bi bi-chat-dots fs-3" aria-hidden="true"></i>
                                    <span class="fw-semibold">Still have a question?</span>
                                </div>
                                <p class="small mb-3 opacity-75">
                                    Message or call us and we'll get back to you during opening hours.
                                </p>
                                <div class="d-flex flex-column gap-2">
                                    <a href="tel:+63288909098" class="text-decoration-none">
                                        <i class="bi bi-telephone-fill me-2" aria-hidden="true"></i>(02) 8890-9098
                                    </a>
                                    <a href="#" class="text-decoration-none">
                                        <i class="bi bi-messenger me-2" aria-hidden="true"></i>Message us on Messenger
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-lg-8">
                        <div class="accordion" id="faqAccordion">
                            <div class="accordion-item">
                                <h3 class="accordion-header">
                                    <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                            data-bs-target="#faq-walkin" aria-expanded="true" aria-controls="faq-walkin">
                                        Do you accept walk-ins?
                                    </button>
                                </h3>
                                <div id="faq-walkin" class="accordion-collapse collapse show" data-bs-parent="#faqAccordion">
                                    <div class="accordion-body">
                                        Yes, we welcome walk-ins whenever a stylist or therapist is free. For color,
                                        treatments, and massage, we recommend booking ahead so your slot is guaranteed.
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h3 class="accordion-header">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                            data-bs-target="#faq-book" aria-expanded="false" aria-controls="faq-book">
                                        How do I book an appointment?
                                    </button>
                                </h3>
                                <div id="faq-book" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                                    <div class="accordion-body">
                                        Message us on Messenger or call the shop. Tell us the service, your preferred
                                        date and time, and your name, and we'll confirm your slot.
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h3 class="accordion-header">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                            data-bs-target="#faq-pay" aria-expanded="false" aria-controls="faq-pay">
                                        What payment methods do you accept?
                                    </button>
                                </h3>
                                <div id="faq-pay" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                                    <div class="accordion-body">
                                        We accept cash, GCash, and major credit and debit cards. Payment is made after
                                        your service, unless it's a package that needs a deposit.
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h3 class="accordion-header">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                            data-bs-target="#faq-resched" aria-expanded="false" aria-controls="faq-resched">
                                        Can I cancel or reschedule?
                                    </button>
                                </h3>
                                <div id="faq-resched" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                                    <div class="accordion-body">
                                        Of course. Please let us know at least 24 hours before your appointment so we
                                        can offer the slot to someone else and find you a new time.
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h3 class="accordion-header">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                            data-bs-target="#faq-late" aria-expanded="false" aria-controls="faq-late">
                                        What if I'm running late?
                                    </button>
                                </h3>
                                <div id="faq-late" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                                    <div class="accordion-body">
                                        Send us a message as soon as you know. We'll hold your slot for a short while,
                                        and if we can't fit your full service in, we'll offer a shorter one or a new time.
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h3 class="accordion-header">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                            data-bs-target="#faq-color" aria-expanded="false" aria-controls="faq-color">
                                        How long do hair color and treatments take?
                                    </button>
                                </h3>
                                <div id="faq-color" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                                    <div class="accordion-body">
                                        A haircut takes about an hour. Hair color and rebond can take two to four hours,
                                        depending on your hair length and the result you want. We'll give you an estimate
                                        when you book.
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h3 class="accordion-header">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                            data-bs-target="#faq-allergy" aria-expanded="false" aria-controls="faq-allergy">
                                        I have sensitive skin or allergies. Is that okay?
                                    </button>
                                </h3>
                                <div id="faq-allergy" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                                    <div class="accordion-body">
                                        Please tell us before your service. We can do a patch test for hair color, and
                                        we'll choose gentler products for facials and massage oils.
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h3 class="accordion-header">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                            data-bs-target="#faq-preg" aria-expanded="false" aria-controls="faq-preg">
                                        Can I get a massage if I'm pregnant?
                                    </button>
                                </h3>
                                <div id="faq-preg" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                                    <div class="accordion-body">
                                        Let us know when you book so we can assign a therapist and adjust the treatment.
                                        We also suggest checking with your doctor first.
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h3 class="accordion-header">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                            data-bs-target="#faq-kids" aria-expanded="false" aria-controls="faq-kids">
                                        Do you serve kids, and can I bring a friend?
                                    </button>
                                </h3>
                                <div id="faq-kids" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                                    <div class="accordion-body">
                                        Yes, we do kids' haircuts, and you're welcome to bring a friend or family member.
                                        For group bookings, message us ahead so we can line up the time slots together.
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
    
   
    <footer class="bg-custom-brown text-white mt-auto py-5">
        <div class="container">
            <div class="row gy-4">
                <div class="col-lg-5">
                    <div class="d-flex align-items-center mb-3">
                        <img src="Logo/circular-logo.png"
                            alt="Logo"
                            class="img-fluid"
                            style="max-height:70px;">
                        <div class="ms-3">
                            <h4 class="mb-0">LINY DELOS REYES</h4>
                            <h6 class="mb-0">Salon & Spa</h6>
                        </div>
                    </div>
                    <p class="text-light">
                        Experience beauty, relaxation, and wellness through premium
                        salon and spa services.
                    </p>
                    <p class="mb-0 text-light">
                        Caloocan City, Philippines
                    </p>
                </div>
                <div class="col-md-3 col-lg-2">
                    <h5 class="text-uppercase fw-bold mb-3">About</h5>
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="#">Home</a></li>
                        <li class="mb-2"><a href="#">About Us</a></li>
                        <li class="mb-2"><a href="#">FAQS</a></li>
                        <li><a href="#">Contact</a></li>
                    </ul>
                </div>
                <div class="col-md-3 col-lg-2">
                    <h5 class="text-uppercase fw-bold mb-3">Services</h5>
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="#">Hair Care</a></li>
                        <li class="mb-2"><a href="#">Hair Color</a></li>
                        <li class="mb-2"><a href="#">Facial</a></li>
                        <li><a href="#">Massage</a></li>
                    </ul>
                </div>
                <div class="col-md-6 col-lg-3">
                    <h5 class="text-uppercase fw-bold mb-3">Follow Us</h5>
                    <div class="d-flex gap-3">
                        <a href="#">
                            <i class="bi bi-facebook"></i>
                        </a>
                        <a href="#">
                            <i class="bi bi-instagram"></i>
                        </a>
                        <a href="#">
                            <i class="bi bi-tiktok"></i>
                        </a>
                    </div>
                    <div class="mt-4">
                        <p class="mb-1">
                            <i class="bi bi-telephone-fill me-2"></i>
                            (02) 8890-9098
                        </p>
                        <p class="mb-0">
                            <i class="bi bi-envelope-fill me-2"></i>
                            info@linydelosreyes.com
                        </p>
                    </div>
                </div>
            </div>

            <hr class="my-4">

            <div class="row text-center text-lg-start">
                <div class="col-lg-6">
                    <small>
                        © 2026 Liny Delos Reyes Salon & Spa. All Rights Reserved.
                    </small>
                </div>
                <div class="col-lg-6 text-lg-end mt-2 mt-lg-0">
                    <small>
                        <a href="#">Privacy Policy</a>
                        <span class="mx-2">|</span>
                        <a href="#">Terms & Conditions</a>
                    </small>
                </div>
            </div>
        </div>
    </footer>

    <script>
        $(function () {
            var days = ['SUNDAY','MONDAY','TUESDAY','WEDNESDAY','THURSDAY','FRIDAY','SATURDAY'];
            var months = ['JANUARY','FEBRUARY','MARCH','APRIL','MAY','JUNE','JULY','AUGUST','SEPTEMBER','OCTOBER','NOVEMBER','DECEMBER'];
            var now = new Date();
            var formatted = days[now.getDay()] + ' · ' + now.getDate() + ' ' + months[now.getMonth()] + ' ' + now.getFullYear();
            $('#dateLabel').text(formatted);
        });
    </script>
</body>
</html>