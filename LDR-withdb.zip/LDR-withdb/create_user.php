<?php
if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

if ($argc !== 4) {
    fwrite(STDERR, "Usage: php create_user.php <username> <password> <admin|owner|staff>" . PHP_EOL);
    exit(1);
}

$username = trim($argv[1]);
$password = $argv[2];
$role = $argv[3];

if ($username === '' || strlen($username) > 50 || $password === '' ||
    !in_array($role, ['admin', 'owner', 'staff'], true)) {
    fwrite(STDERR, "Provide a username (up to 50 characters), a password, and a valid role." . PHP_EOL);
    exit(1);
}

include('connect.php');
if ($error) {
    fwrite(STDERR, $error . PHP_EOL);
    exit(1);
}

$passwordHash = password_hash($password, PASSWORD_DEFAULT);

$stmt = $conn->prepare(
    "INSERT INTO users (username, password_hash, role)
     VALUES (?, ?, ?)"
);

$stmt->bind_param("sss", $username, $passwordHash, $role);

try {
    $stmt->execute();
    echo "Account created successfully!" . PHP_EOL;
} catch (mysqli_sql_exception $e) {
    fwrite(STDERR, "Could not create account. The username may already exist." . PHP_EOL);
    exit(1);
}

$stmt->close();
?>
