<?php
include('connect.php');
if ($error) { http_response_code(500); echo $error; exit; }

$id      = (int)($_POST['id'] ?? 0);
$clientId = (int)($_POST['client_id'] ?? 0);
$serviceId = (int)($_POST['service_id'] ?? 0);
$stylist = trim($_POST['stylist'] ?? '');
$date    = $_POST['date'] ?? '';
$time    = $_POST['time'] ?? '';
$status  = $_POST['status'] ?? 'pending';
$price   = (float)($_POST['price'] ?? 0);
$notes   = trim($_POST['notes'] ?? '');

if ($clientId < 1 || $date === '' || $time === '' ||
    !in_array($status, ['pending', 'confirmed', 'completed', 'cancelled'], true)) {
    http_response_code(400);
    echo 'Select a client, choose a valid status, and fill in the required appointment fields.';
    exit;
}

$clientStmt = $conn->prepare("SELECT name, phone FROM clients WHERE id = ?");
$clientStmt->bind_param("i", $clientId);
$clientStmt->execute();
$clientRecord = $clientStmt->get_result()->fetch_assoc();
if (!$clientRecord) {
    http_response_code(400);
    echo 'Select a client that already exists.';
    exit;
}
$client = $clientRecord['name'];
$phone = $clientRecord['phone'];

$serviceCategory = '';
if ($serviceId > 0) {
    $serviceStmt = $conn->prepare("SELECT name, category FROM services WHERE id = ? AND status = 'Active'");
    $serviceStmt->bind_param("i", $serviceId);
    $serviceStmt->execute();
    $serviceRow = $serviceStmt->get_result()->fetch_assoc();
    $service = $serviceRow['name'] ?? '';
    $serviceCategory = $serviceRow['category'] ?? '';
} elseif ($id > 0) {
    $serviceStmt = $conn->prepare("SELECT service FROM appointments WHERE id = ?");
    $serviceStmt->bind_param("i", $id);
    $serviceStmt->execute();
    $service = $serviceStmt->get_result()->fetch_assoc()['service'] ?? '';
    if ($service !== '') {
        $categoryStmt = $conn->prepare("SELECT category FROM services WHERE name = ? LIMIT 1");
        $categoryStmt->bind_param("s", $service);
        $categoryStmt->execute();
        $serviceCategory = (string)($categoryStmt->get_result()->fetch_assoc()['category'] ?? '');
    }
} else {
    $service = '';
}

if ($service === '' || $serviceCategory === '') {
    http_response_code(400);
    echo 'Select an active service before saving the appointment.';
    exit;
}

try {
    $conn->begin_transaction();

    if ($status === 'completed') {
        if ($id > 0) {
            $checkStmt = $conn->prepare("SELECT id FROM appointments WHERE id = ? FOR UPDATE");
            $checkStmt->bind_param("i", $id);
            $checkStmt->execute();
            if (!$checkStmt->get_result()->fetch_assoc()) {
                $conn->rollback();
                http_response_code(404);
                echo 'Appointment not found.';
                exit;
            }
        }

        $saleStmt = $conn->prepare(
            "INSERT INTO sales (client, phone, service, service_category, stylist, sale_date, sale_time, status, price, notes)
             VALUES (?, ?, ?, ?, ?, ?, ?, 'completed', ?, ?)"
        );
        $saleStmt->bind_param("sssssssds", $client, $phone, $service, $serviceCategory, $stylist, $date, $time, $price, $notes);
        $saleStmt->execute();
        $saleId = $conn->insert_id;

        if ($id > 0) {
            $deleteStmt = $conn->prepare("DELETE FROM appointments WHERE id = ?");
            $deleteStmt->bind_param("i", $id);
            $deleteStmt->execute();
        }

        $conn->commit();
        echo $saleId;
        exit;
    }

    if ($id === 0) {
        $stmt = $conn->prepare(
            "INSERT INTO appointments (client, phone, service, stylist, appt_date, appt_time, status, price, notes)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"
        );
        $stmt->bind_param("sssssssds", $client, $phone, $service, $stylist, $date, $time, $status, $price, $notes);
        $stmt->execute();
        $id = $conn->insert_id;
    } else {
        $stmt = $conn->prepare(
            "UPDATE appointments
             SET client=?, phone=?, service=?, stylist=?, appt_date=?, appt_time=?, status=?, price=?, notes=?
             WHERE id=?"
        );
        $stmt->bind_param("sssssssdsi", $client, $phone, $service, $stylist, $date, $time, $status, $price, $notes, $id);
        $stmt->execute();
    }

    $conn->commit();
    echo $id;
} catch (mysqli_sql_exception $e) {
    $conn->rollback();
    http_response_code(500);
    echo 'Could not save the appointment.';
}