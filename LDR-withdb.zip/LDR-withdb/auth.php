<?php

function require_authenticated_user(array $allowedRoles = ['admin', 'owner', 'staff']): void
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        header('Allow: POST');
        echo 'Method not allowed.';
        exit;
    }

    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        echo 'Authentication required.';
        exit;
    }

    if (!in_array($_SESSION['role'] ?? '', $allowedRoles, true)) {
        http_response_code(403);
        echo 'You are not allowed to perform this action.';
        exit;
    }
}
